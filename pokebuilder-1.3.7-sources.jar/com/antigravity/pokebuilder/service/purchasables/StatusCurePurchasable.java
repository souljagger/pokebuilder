package com.antigravity.pokebuilder.service.purchasables;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.PokeBuilderConstants;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.Purchasable;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

// Instant purchasable. Eligible only when the Pokémon currently has a
// persistent status (poison, burn, paralysis, freeze, sleep). Greyed
// out via the eligibility() hook when the Pokémon is already healthy
// so players don't waste a click.
public final class StatusCurePurchasable implements Purchasable {

    @Override public String id() { return "status_cure"; }
    @Override public FeatureGate.Feature feature() { return FeatureGate.Feature.STATUS_CURE; }
    @Override public String permission() { return PokeBuilderConstants.PERM_MOD_STATUS_CURE; }
    @Override public int editorSlot() { return 24; }

    @Override
    public class_1799 icon(Pokemon pokemon, class_3222 who) {
        BigDecimal cost = PokeBuilder.get().config().prices.statusCure;
        boolean hasStatus = hasStatus(pokemon);
        if (!hasStatus) {
            return ItemBuilder.of(class_1802.field_8871)
                    .name("Status Cure", class_124.field_1063, class_124.field_1067, class_124.field_1055)
                    .lore("Pokémon is already healthy.", class_124.field_1063)
                    .build();
        }
        String statusName = statusName(pokemon);
        return ItemBuilder.of(class_1802.field_20417)
                .name("Status Cure", class_124.field_1060, class_124.field_1067)
                .lore("Current: " + statusName, class_124.field_1054)
                .lore("Cost: " + TextHelper.formatMoney(cost) + " " + TextHelper.currencyName(),
                        class_124.field_1054)
                .lore("Click to heal", class_124.field_1080)
                .glow(true)
                .build();
    }

    @Override
    public BigDecimal basePrice(Pokemon pokemon, class_3222 who) {
        return PokeBuilder.get().config().prices.statusCure;
    }

    @Override
    public Eligibility eligibility(Pokemon pokemon, class_3222 who) {
        return hasStatus(pokemon) ? Eligibility.OK
                : Eligibility.denied("status.already_healthy");
    }

    @Override
    public void invoke(class_3222 player, UUID pokemonId) {
        Pokemon pokemon = CobblemonBridge.findByUuid(player, pokemonId);
        if (pokemon == null) return;
        if (!hasStatus(pokemon)) {
            player.method_7353(PokeBuilder.get().config().messages.get("status.already_healthy"), false);
            return;
        }
        BigDecimal cost = basePrice(pokemon, player);
        String prev = statusName(pokemon);
        TransactionService.Result r = TransactionService.execute(player, pokemonId, feature(),
                id().toUpperCase(), prev, cost,
                PokemonModifier::clearStatus);
        if (r == TransactionService.Result.SUCCESS) {
            player.method_7353(PokeBuilder.get().config().messages.get("status.cured"), false);
        }
    }

    private boolean hasStatus(Pokemon pokemon) {
        try {
            return pokemon.getStatus() != null;
        } catch (Throwable t) { return false; }
    }

    private String statusName(Pokemon pokemon) {
        try {
            var container = pokemon.getStatus();
            if (container == null) return "—";
            var ps = container.getStatus();
            if (ps == null) return "—";
            return ps.getShowdownName();
        } catch (Throwable t) {
            return "status";
        }
    }
}
