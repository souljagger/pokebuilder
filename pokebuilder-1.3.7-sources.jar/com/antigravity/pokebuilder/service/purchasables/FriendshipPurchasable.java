package com.antigravity.pokebuilder.service.purchasables;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.PokeBuilderConstants;
import com.antigravity.pokebuilder.gui.FriendshipGui;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.Purchasable;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

public final class FriendshipPurchasable implements Purchasable {

    @Override public String id() { return "friendship"; }
    @Override public FeatureGate.Feature feature() { return FeatureGate.Feature.FRIENDSHIP; }
    @Override public String permission() { return PokeBuilderConstants.PERM_MOD_FRIENDSHIP; }
    @Override public int editorSlot() { return 22; }

    @Override
    public class_1799 icon(Pokemon pokemon, class_3222 who) {
        int current = safeFriendship(pokemon);
        BigDecimal step = PokeBuilder.get().config().prices.friendshipPerStep;
        return ItemBuilder.of(class_1802.field_8880)
                .name("Friendship: " + current + " / 255", class_124.field_1076, class_124.field_1067)
                .lore("Cost per +10: " + TextHelper.formatMoney(step) + " "
                        + TextHelper.currencyName(), class_124.field_1054)
                .lore("Click to open the friendship picker.", class_124.field_1080)
                .glow(current == 255)
                .build();
    }

    @Override
    public BigDecimal basePrice(Pokemon pokemon, class_3222 who) {
        return PokeBuilder.get().config().prices.friendshipPerStep;
    }

    @Override
    public void invoke(class_3222 player, UUID pokemonId) {
        new FriendshipGui(player, pokemonId).open();
    }

    private int safeFriendship(Pokemon p) {
        try { return p.getFriendship(); } catch (Throwable t) { return 0; }
    }
}
