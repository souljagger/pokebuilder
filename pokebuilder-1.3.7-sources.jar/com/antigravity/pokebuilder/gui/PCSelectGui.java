package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonValidator;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.cobblemon.mod.common.api.pokemon.stats.Stats;
import com.cobblemon.mod.common.api.storage.pc.PCBox;
import com.cobblemon.mod.common.api.storage.pc.PCStore;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

// Paginated read-only browser of the player's PC. Each click opens the
// EditorGui on the selected Pokémon, which then goes through the normal
// transaction flow — the PC access is a *lookup* on top of the existing
// per-player locked pipeline, not a parallel one.
//
// One box at a time (30 slots in a 5×6 grid). Box name + number on the
// banner in the bottom bar. Prev / Next / Back-to-Party buttons live
// in the bottom row alongside the banner.
//
// Security boundaries enforced here AND in CobblemonBridge.findByUuid:
//   - Constructor only accepts the requesting player — no target arg,
//     so there's no API surface to open someone else's PC.
//   - PC_ACCESS feature gate refuses to render if disabled server-wide.
//   - Concurrent mutation (Pokémon trade / move / release) is caught at
//     transaction time when findByUuid returns null and the editor
//     aborts with transaction.pokemon_gone.
public class PCSelectGui extends BaseGui {

    // Layout (6-row chest, 54 slots total):
    //   row 0     ─ box slots 0..5  in cols 1..6 (overwrites top border)
    //   row 1..4  ─ box slots 6..29 in cols 1..6
    //   row 5     ─ entire bottom bar (PREV / INFO / PARTY / NEXT / CLOSE)
    // Cols 0 and 7..8 of every row stay as decorative glass walls.
    // 5 rows × 6 cols = 30 = exact PC box size. No collisions, no waste.
    private static final int BOX_SIZE = 30;

    private static final int PREV_SLOT = 45;
    private static final int BOX_INFO_SLOT = 47;
    private static final int PARTY_TOGGLE_SLOT = 49;
    private static final int NEXT_SLOT = 51;
    private static final int CLOSE_SLOT = 53;

    private int boxIndex = 0;

    public PCSelectGui(class_3222 player) {
        this(player, 0);
    }

    public PCSelectGui(class_3222 player, int boxIndex) {
        super(player, 6, PokeBuilder.get().config().messages.get("gui.title.pc"));
        this.boxIndex = Math.max(0, boxIndex);
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);

        PCStore pc = CobblemonBridge.getPC(player);
        if (pc == null) {
            safeSet(22, ItemBuilder.of(class_1802.field_8077)
                    .name("PC unavailable", class_124.field_1061, class_124.field_1067)
                    .lore("Your PC isn't loaded yet.", class_124.field_1080)
                    .lore("Try again in a moment.", class_124.field_1063)
                    .build());
            safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
            return;
        }

        List<PCBox> boxes = pc.getBoxes();
        int totalBoxes = boxes.size();
        if (totalBoxes == 0) {
            safeSet(22, ItemBuilder.of(class_1802.field_8077)
                    .name("Empty PC", class_124.field_1080, class_124.field_1067)
                    .build());
            return;
        }
        if (boxIndex >= totalBoxes) boxIndex = totalBoxes - 1;
        if (boxIndex < 0) boxIndex = 0;

        PCBox box = boxes.get(boxIndex);
        renderBox(box, boxIndex, totalBoxes);
    }

    private void renderBox(PCBox box, int index, int total) {
        // Slots 0..BOX_SIZE-1 map to grid positions 10..16, 19..25, 28..34, 37..39.
        // Stop at slot 30-ish so we don't collide with the bottom bar.
        for (int i = 0; i < BOX_SIZE; i++) {
            int slot = slotFor(i);
            Pokemon p;
            try { p = box.get(i); } catch (Throwable t) { p = null; }
            safeSet(slot, renderPokemon(p));
        }

        // box.getName() is null for never-renamed PC boxes (Cobblemon
        // only sets a name when the player explicitly renames a box).
        // Default to "Box N" so the lore line is never empty.
        String boxName = box.getName();
        if (boxName == null || boxName.isBlank()) {
            boxName = "Box " + (index + 1);
        }
        safeSet(BOX_INFO_SLOT, ItemBuilder.of(class_1802.field_8466)
                .name(PokeBuilder.get().config().messages.get(
                        "gui.label.pc_box", (index + 1), total).getString(),
                        class_124.field_1075, class_124.field_1067)
                .lore(boxName, class_124.field_1080)
                .build());

        if (index > 0) {
            safeSet(PREV_SLOT, ItemBuilder.of(class_1802.field_8236)
                    .name(PokeBuilder.get().config().messages.get("gui.label.pc_prev_box").getString(),
                            class_124.field_1054, class_124.field_1067)
                    .build());
        }
        if (index < total - 1) {
            safeSet(NEXT_SLOT, ItemBuilder.of(class_1802.field_8236)
                    .name(PokeBuilder.get().config().messages.get("gui.label.pc_next_box").getString(),
                            class_124.field_1054, class_124.field_1067)
                    .build());
        }
        safeSet(PARTY_TOGGLE_SLOT, ItemBuilder.of(class_1802.field_8674)
                .name(PokeBuilder.get().config().messages.get("gui.label.switch_to_party").getString(),
                        class_124.field_1060, class_124.field_1067)
                .lore("Return to your party view.", class_124.field_1080)
                .build());
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061, class_124.field_1067).build());
    }

    // Map logical PC slot (0..29) to inventory slot, using a 5×6 grid
    // anchored at row 0 col 1 (so cols 0, 7, 8 stay as wall padding).
    //   box  0..5  → row 0 cols 1..6 → slots 1..6
    //   box  6..11 → row 1 cols 1..6 → slots 10..15
    //   box 12..17 → row 2 cols 1..6 → slots 19..24
    //   box 18..23 → row 3 cols 1..6 → slots 28..33
    //   box 24..29 → row 4 cols 1..6 → slots 37..42
    private static int slotFor(int slotInBox) {
        int cols = 6;
        int row = slotInBox / cols;     // 0..4
        int col = slotInBox % cols;     // 0..5
        return row * 9 + (col + 1);     // rows 0..4, cols 1..6
    }

    private class_1799 renderPokemon(Pokemon p) {
        if (p == null) {
            return ItemBuilder.of(class_1802.field_8240)
                    .name(PokeBuilder.get().config().messages.get("gui.label.empty_slot").getString(),
                            class_124.field_1063)
                    .build();
        }
        if (PokemonValidator.isEgg(p)) {
            return ItemBuilder.of(class_1802.field_8618)
                    .name("Egg", class_124.field_1080, class_124.field_1056)
                    .lore("Eggs cannot be modified", class_124.field_1063)
                    .build();
        }
        boolean blocked = PokemonValidator.isBlocked(p);
        boolean shiny = p.getShiny();
        class_1799 stack = blocked ? new class_1799(class_1802.field_8077) : ModItems.pokemonIcon(p);

        Stats[] stats = CobblemonBridge.allStats();
        String ivs = String.format("%d/%d/%d/%d/%d/%d",
                p.getIvs().get(stats[0]), p.getIvs().get(stats[1]),
                p.getIvs().get(stats[2]), p.getIvs().get(stats[3]),
                p.getIvs().get(stats[4]), p.getIvs().get(stats[5]));
        String evs = String.format("%d/%d/%d/%d/%d/%d",
                p.getEvs().get(stats[0]), p.getEvs().get(stats[1]),
                p.getEvs().get(stats[2]), p.getEvs().get(stats[3]),
                p.getEvs().get(stats[4]), p.getEvs().get(stats[5]));

        ItemBuilder b = ItemBuilder.of(stack)
                .name((shiny ? "\u2728 " : "") + capitalize(p.getSpecies().getName()) + "  Lv." + p.getLevel(),
                        blocked ? class_124.field_1061 : (shiny ? class_124.field_1075 : class_124.field_1060),
                        class_124.field_1067)
                .lore("Nature: " + capitalize(p.getNature().getName().method_12832()), class_124.field_1080)
                .lore("Ability: " + (p.getAbility() != null ? p.getAbility().getTemplate().getName() : "—"), class_124.field_1080)
                .lore("IVs: " + ivs, class_124.field_1080)
                .lore("EVs: " + evs, class_124.field_1080)
                .lore(blocked ? "\u2716 Blocked by server rules" : "Click to edit",
                        blocked ? class_124.field_1061 : class_124.field_1054);
        if (shiny) b.glow(true);
        return b.build();
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return "—";
        return Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase();
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (slot == CLOSE_SLOT) { close(); return; }
        if (slot == PARTY_TOGGLE_SLOT) { SoundHelper.back(player); new PartySelectGui(player).open(); return; }
        if (slot == PREV_SLOT) { boxIndex = Math.max(0, boxIndex - 1); refresh(); return; }
        if (slot == NEXT_SLOT) { boxIndex = boxIndex + 1; refresh(); return; }

        // Must also re-check the feature gate here — an admin could
        // disable PC access while the player has this GUI open.
        if (!FeatureGate.enforce(FeatureGate.Feature.PC_ACCESS, player)) {
            close();
            return;
        }

        PCStore pc = CobblemonBridge.getPC(player);
        if (pc == null) return;
        List<PCBox> boxes = pc.getBoxes();
        if (boxIndex >= boxes.size()) return;
        PCBox box = boxes.get(boxIndex);

        // Reverse slotFor(): map grid slot back to box index.
        int boxSlot = boxSlotFor(slot);
        if (boxSlot < 0 || boxSlot >= BOX_SIZE) return;

        Pokemon p;
        try { p = box.get(boxSlot); } catch (Throwable t) { return; }
        if (p == null || PokemonValidator.isEgg(p)) return;
        if (PokemonValidator.isBlocked(p)) {
            player.method_7353(class_2561.method_43470("This Pokémon cannot be modified.")
                    .method_27692(class_124.field_1061), false);
            return;
        }
        SoundHelper.selectPokemon(player);
        new EditorGui(player, p.getUuid()).open();
    }

    private static int boxSlotFor(int inventorySlot) {
        // Inverse of slotFor: rows 0..4, cols 1..6.
        int row = inventorySlot / 9;
        int col = inventorySlot % 9;
        if (row < 0 || row > 4 || col < 1 || col > 6) return -1;
        int boxSlot = row * 6 + (col - 1);
        return boxSlot < BOX_SIZE ? boxSlot : -1;
    }

    @Override
    protected void onOpen() {
        SoundHelper.openMenu(player);
    }
}
