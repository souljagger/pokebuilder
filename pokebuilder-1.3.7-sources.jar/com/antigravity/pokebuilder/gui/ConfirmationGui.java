package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.economy.EconomyHandler;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ConfirmationGui extends BaseGui {

    private static final int INFO_SLOT = 4;
    private static final int CONFIRM_SLOT = 11;
    private static final int CANCEL_SLOT = 15;

    private final UUID pokemonId;
    private final String description;
    private final BigDecimal cost;
    private final Consumer<Pokemon> onConfirm;

    public ConfirmationGui(class_3222 player, UUID pokemonId, String description,
                           BigDecimal cost, Consumer<Pokemon> onConfirm) {
        super(player, 3, class_2561.method_43470("Confirm Purchase").method_27692(class_124.field_1062));
        this.pokemonId = pokemonId;
        this.description = description;
        this.cost = cost;
        this.onConfirm = onConfirm;
    }

    @Override
    protected void build() {
        fillBorders(7);
        BigDecimal balance = EconomyHandler.isReady() ? EconomyHandler.getBalance(player.method_5667()) : BigDecimal.ZERO;
        BigDecimal after = balance.subtract(cost);

        safeSet(INFO_SLOT, ItemBuilder.of(class_1802.field_8407)
                .name("Confirm Purchase", class_124.field_1065, class_124.field_1067)
                .lore("Change: " + description, class_124.field_1080)
                .lore("Cost: " + TextHelper.formatMoney(cost) + " " + TextHelper.currencyName(), class_124.field_1054)
                .lore("Balance after: " + TextHelper.formatMoney(after) + " " + TextHelper.currencyName(), class_124.field_1054)
                .build());

        safeSet(CONFIRM_SLOT, ItemBuilder.of(class_1802.field_19049)
                .name("CONFIRM", class_124.field_1060, class_124.field_1067).build());
        safeSet(CANCEL_SLOT, ItemBuilder.of(class_1802.field_19058)
                .name("CANCEL", class_124.field_1061, class_124.field_1067).build());
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (slot == CONFIRM_SLOT) {
            Pokemon p = com.antigravity.pokebuilder.service.CobblemonBridge.findByUuid(player, pokemonId);
            if (p != null) {
                onConfirm.accept(p);
            }
        } else if (slot == CANCEL_SLOT) {
            SoundHelper.back(player);
            new EditorGui(player, pokemonId).open();
        }
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
