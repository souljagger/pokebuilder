package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.MegaShowdownBridge;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class DynamaxLevelGui extends BaseGui {

    private static final int INFO_SLOT = 4;
    private static final int BACK_SLOT = 45;
    private static final int BALANCE_SLOT = 49;
    private static final int CLOSE_SLOT = 53;

    private final UUID pokemonId;

    public DynamaxLevelGui(class_3222 player, UUID pokemonId) {
        super(player, 6, class_2561.method_43470("PokeBuilder — Dynamax Level").method_27692(class_124.field_1076));
        this.pokemonId = pokemonId;
    }

    @Override
    protected void build() {
        fillBorders(10);
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }

        int max = MegaShowdownBridge.maxDynamaxLevel();
        int current = safeCurrentLevel(p);
        BigDecimal step = PokeBuilder.get().config().prices.dynamaxLevelPerStep;

        safeSet(INFO_SLOT, ItemBuilder.of(ModItems.dynamaxBand())
                .name("Dynamax Level " + current + " / " + max,
                        class_124.field_1076, class_124.field_1067)
                .lore("Price per level: " + TextHelper.formatMoney(step) + " " + TextHelper.currencyName(), class_124.field_1054)
                .lore("Click a level below to set it.", class_124.field_1080)
                .glow(current == max)
                .build());

        // Ten (or N) level buttons on rows 2-3, plus a "0" reset and a "Max" shortcut.
        int[] rowSlots = new int[] {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        for (int lvl = 0; lvl <= max && lvl < rowSlots.length; lvl++) {
            boolean isCurrent = (lvl == current);
            BigDecimal cost = costFromCurrent(current, lvl, step);
            // Each level button is a stack of dynamax candies sized to the level.
            ItemBuilder b = ItemBuilder.of(lvl == 0 ? class_1802.field_8871 : ModItems.dynamaxCandy())
                    .name("Level " + lvl, isCurrent ? class_124.field_1060 : class_124.field_1076, class_124.field_1067)
                    .count(Math.max(1, Math.min(64, lvl + 1)));
            if (isCurrent) {
                b.lore("[CURRENT]", class_124.field_1060, class_124.field_1067).glow(true);
            } else {
                if (cost.signum() == 0) {
                    b.lore("Free (decrease)", class_124.field_1080);
                } else {
                    b.lore("Cost: " + TextHelper.formatMoney(cost) + " " + TextHelper.currencyName(), class_124.field_1054);
                }
                b.lore("Click to set", class_124.field_1080);
            }
            safeSet(rowSlots[lvl], b.build());
        }

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        safeSet(BALANCE_SLOT, balanceItem());
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
    }

    private BigDecimal costFromCurrent(int current, int target, BigDecimal step) {
        if (target <= current) return BigDecimal.ZERO;
        return step.multiply(BigDecimal.valueOf(target - current));
    }

    private class_1799 balanceItem() {
        return ItemBuilder.of(class_1802.field_8695)
                .name("Balance: " + TextHelper.formatMoney(
                        com.antigravity.pokebuilder.economy.EconomyHandler.isReady()
                                ? com.antigravity.pokebuilder.economy.EconomyHandler.getBalance(player.method_5667())
                                : BigDecimal.ZERO) + " " + TextHelper.currencyName(),
                        class_124.field_1065, class_124.field_1067)
                .build();
    }

    private int safeCurrentLevel(Pokemon p) {
        try { return p.getDmaxLevel(); } catch (Throwable t) { return 0; }
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (slot == BACK_SLOT) { SoundHelper.back(player); new EditorGui(player, pokemonId).open(); return; }
        if (slot == CLOSE_SLOT) { close(); return; }

        int max = MegaShowdownBridge.maxDynamaxLevel();
        int[] rowSlots = new int[] {19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
        for (int lvl = 0; lvl <= max && lvl < rowSlots.length; lvl++) {
            if (rowSlots[lvl] == slot) {
                applyLevel(lvl);
                return;
            }
        }
    }

    private void applyLevel(int target) {
        if (!FeatureGate.enforce(FeatureGate.Feature.DYNAMAX_LEVEL, player)) { close(); return; }
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }
        int current = safeCurrentLevel(p);
        if (target == current) return;

        BigDecimal step = PokeBuilder.get().config().prices.dynamaxLevelPerStep;
        BigDecimal cost = costFromCurrent(current, target, step);

        TransactionService.execute(player, pokemonId, FeatureGate.Feature.DYNAMAX_LEVEL,
                "DYNAMAX_LEVEL", String.valueOf(target), cost,
                pm -> PokemonModifier.setDynamaxLevel(pm, target));
        refresh();
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
