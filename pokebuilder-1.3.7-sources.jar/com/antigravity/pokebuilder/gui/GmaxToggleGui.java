package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.economy.EconomyHandler;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class GmaxToggleGui extends BaseGui {

    private static final int INFO_SLOT = 4;
    private static final int TOGGLE_SLOT = 22;
    private static final int BACK_SLOT = 45;
    private static final int BALANCE_SLOT = 49;
    private static final int CLOSE_SLOT = 53;

    private final UUID pokemonId;

    public GmaxToggleGui(class_3222 player, UUID pokemonId) {
        super(player, 6, class_2561.method_43470("PokeBuilder — G-Max Factor").method_27692(class_124.field_1076));
        this.pokemonId = pokemonId;
    }

    @Override
    protected void build() {
        fillBorders(10);
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }

        boolean hasFactor = safeGmax(p);
        BigDecimal cost = PokeBuilder.get().config().prices.gmaxFactor;

        safeSet(INFO_SLOT, ItemBuilder.of(ModItems.dynamaxBand())
                .name("Gigantamax Factor", class_124.field_1076, class_124.field_1067)
                .lore("Current: " + (hasFactor ? "UNLOCKED" : "Locked"),
                        hasFactor ? class_124.field_1060 : class_124.field_1080)
                .lore("Grants access to the G-Max form", class_124.field_1063)
                .lore("when this species supports it.", class_124.field_1063)
                .glow(hasFactor)
                .build());

        safeSet(TOGGLE_SLOT, ItemBuilder.of(hasFactor ? class_1802.field_8879 : ModItems.maxMushroom())
                .name(hasFactor ? "Remove G-Max Factor" : "Grant G-Max Factor",
                        class_124.field_1076, class_124.field_1067)
                .lore(hasFactor ? "Free — removes the factor" : "Cost: " + TextHelper.formatMoney(cost) + " " + TextHelper.currencyName(),
                        hasFactor ? class_124.field_1080 : class_124.field_1054)
                .lore("Click to " + (hasFactor ? "remove" : "grant"), class_124.field_1080)
                .glow(!hasFactor)
                .build());

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        safeSet(BALANCE_SLOT, balanceItem());
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
    }

    private class_1799 balanceItem() {
        BigDecimal bal = EconomyHandler.isReady() ? EconomyHandler.getBalance(player.method_5667()) : BigDecimal.ZERO;
        return ItemBuilder.of(class_1802.field_8695)
                .name("Balance: " + TextHelper.formatMoney(bal) + " " + TextHelper.currencyName(),
                        class_124.field_1065, class_124.field_1067)
                .build();
    }

    private boolean safeGmax(Pokemon p) {
        try { return p.getGmaxFactor(); } catch (Throwable t) { return false; }
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (slot == BACK_SLOT) { SoundHelper.back(player); new EditorGui(player, pokemonId).open(); return; }
        if (slot == CLOSE_SLOT) { close(); return; }
        if (slot == TOGGLE_SLOT) {
            if (!FeatureGate.enforce(FeatureGate.Feature.GMAX_FACTOR, player)) return;
            Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
            if (p == null) { close(); return; }
            boolean target = !safeGmax(p);
            BigDecimal cost = target ? PokeBuilder.get().config().prices.gmaxFactor : BigDecimal.ZERO;
            TransactionService.execute(player, pokemonId, FeatureGate.Feature.GMAX_FACTOR,
                    "GMAX_FACTOR", target ? "ON" : "OFF", cost,
                    pm -> PokemonModifier.setGmaxFactor(pm, target));
            refresh();
        }
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
