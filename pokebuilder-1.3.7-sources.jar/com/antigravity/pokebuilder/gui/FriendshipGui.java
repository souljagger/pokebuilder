package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.economy.EconomyHandler;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

// Stepper GUI for friendship. Each +N click costs stepCost × N so
// "+50" costs 5x the "+10" price — keeps incentives linear and lets
// admins tune via a single price knob (prices.friendship-per-step).
// "Set to max" costs (255 − current) × stepCost / 10, i.e. the same
// per-point rate as +10. "Reset to 0" is free (parity with other
// "downgrade" flows).
public class FriendshipGui extends BaseGui {

    private static final int INFO_SLOT = 4;
    private static final int PLUS_10_SLOT = 20;
    private static final int PLUS_50_SLOT = 22;
    private static final int MAX_SLOT = 24;
    private static final int RESET_SLOT = 31;
    private static final int BACK_SLOT = 45;
    private static final int BALANCE_SLOT = 49;
    private static final int CLOSE_SLOT = 53;

    private static final int MAX_FRIENDSHIP = 255;

    private final UUID pokemonId;

    public FriendshipGui(class_3222 player, UUID pokemonId) {
        super(player, 6, class_2561.method_43470("❖ PokeBuilder · Friendship ❖")
                .method_27695(class_124.field_1062, class_124.field_1067));
        this.pokemonId = pokemonId;
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }

        int current = safeFriendship(p);
        BigDecimal stepCost = PokeBuilder.get().config().prices.friendshipPerStep;

        safeSet(INFO_SLOT, ItemBuilder.of(class_1802.field_8880)
                .name("Friendship: " + current + " / " + MAX_FRIENDSHIP,
                        class_124.field_1076, class_124.field_1067)
                .lore("Every +10 costs " + TextHelper.formatMoney(stepCost)
                        + " " + TextHelper.currencyName(), class_124.field_1054)
                .lore("Higher friendship evolves certain Pokémon", class_124.field_1063)
                .glow(current == MAX_FRIENDSHIP)
                .build());

        int room = MAX_FRIENDSHIP - current;
        renderStep(PLUS_10_SLOT, class_1802.field_8330, "+10", 10, stepCost, room);
        renderStep(PLUS_50_SLOT, class_1802.field_8330, "+50", 50, stepCost, room);

        int toMax = Math.max(0, MAX_FRIENDSHIP - current);
        BigDecimal maxCost = stepCost.multiply(BigDecimal.valueOf(toMax)).divide(BigDecimal.TEN);
        boolean canMax = toMax > 0;
        safeSet(MAX_SLOT, ItemBuilder.of(canMax ? class_1802.field_8264 : class_1802.field_8298)
                .name(canMax ? "Set to max (255)" : "Already maxed",
                        canMax ? class_124.field_1061 : class_124.field_1063, class_124.field_1067)
                .lore(canMax ? "Cost: " + TextHelper.formatMoney(maxCost) + " "
                                + TextHelper.currencyName()
                        : "", class_124.field_1054)
                .glow(!canMax).build());

        boolean canReset = current > 0;
        safeSet(RESET_SLOT, ItemBuilder.of(canReset ? class_1802.field_8077 : class_1802.field_8298)
                .name(canReset ? "Reset to 0 (free)" : "Already zero",
                        canReset ? class_124.field_1080 : class_124.field_1063, class_124.field_1067)
                .build());

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        safeSet(BALANCE_SLOT, balanceItem());
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061, class_124.field_1067).build());
    }

    private void renderStep(int slot, class_1792 icon, String label, int amount, BigDecimal stepCost, int room) {
        boolean enabled = room > 0;
        int delta = Math.min(amount, room);
        BigDecimal cost = enabled
                ? stepCost.multiply(BigDecimal.valueOf(delta)).divide(BigDecimal.TEN)
                : BigDecimal.ZERO;
        safeSet(slot, ItemBuilder.of(enabled ? icon : class_1802.field_8298)
                .name(label, enabled ? class_124.field_1076 : class_124.field_1063, class_124.field_1067)
                .lore(enabled ? "Cost: " + TextHelper.formatMoney(cost) + " " + TextHelper.currencyName()
                        : "Already at max", class_124.field_1054)
                .glow(!enabled).build());
    }

    private class_1799 balanceItem() {
        BigDecimal bal = EconomyHandler.isReady() ? EconomyHandler.getBalance(player.method_5667()) : BigDecimal.ZERO;
        return ItemBuilder.of(class_1802.field_8695)
                .name("Balance: " + TextHelper.formatMoney(bal) + " " + TextHelper.currencyName(),
                        class_124.field_1065, class_124.field_1067)
                .build();
    }

    private int safeFriendship(Pokemon p) {
        try { return p.getFriendship(); } catch (Throwable t) { return 0; }
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (slot == BACK_SLOT) { SoundHelper.back(player); new EditorGui(player, pokemonId).open(); return; }
        if (slot == CLOSE_SLOT) { close(); return; }
        if (!FeatureGate.enforce(FeatureGate.Feature.FRIENDSHIP, player)) { close(); return; }

        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }
        int current = safeFriendship(p);
        BigDecimal stepCost = PokeBuilder.get().config().prices.friendshipPerStep;

        switch (slot) {
            case PLUS_10_SLOT -> applyDelta(current, 10, stepCost);
            case PLUS_50_SLOT -> applyDelta(current, 50, stepCost);
            case MAX_SLOT -> applyDelta(current, MAX_FRIENDSHIP - current, stepCost);
            case RESET_SLOT -> applySet(0, BigDecimal.ZERO);
            default -> {}
        }
    }

    private void applyDelta(int current, int delta, BigDecimal stepCost) {
        if (delta <= 0) return;
        int room = MAX_FRIENDSHIP - current;
        int actual = Math.min(delta, room);
        if (actual <= 0) return;
        BigDecimal cost = stepCost.multiply(BigDecimal.valueOf(actual)).divide(BigDecimal.TEN);
        TransactionService.execute(player, pokemonId, FeatureGate.Feature.FRIENDSHIP,
                "FRIENDSHIP_ADD", "+" + actual, cost,
                pm -> PokemonModifier.incrementFriendship(pm, actual));
        refresh();
    }

    private void applySet(int target, BigDecimal cost) {
        TransactionService.execute(player, pokemonId, FeatureGate.Feature.FRIENDSHIP,
                "FRIENDSHIP_SET", String.valueOf(target), cost,
                pm -> PokemonModifier.setFriendship(pm, target));
        refresh();
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
