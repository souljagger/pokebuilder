package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.PokeBuilderConstants;
import com.antigravity.pokebuilder.gui.base.BaseGui;
// Diagnostic logging in 1.3.2 to chase the "PC toggle does nothing" report.
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonValidator;
import com.cobblemon.mod.common.api.pokemon.stats.Stats;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.PermissionHelper;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class PartySelectGui extends BaseGui {

    private static final int[] POKE_SLOTS = {10, 11, 12, 13, 14, 15};
    private static final int PC_TOGGLE_SLOT = 22;
    private static final int CLOSE_SLOT = 26;

    public PartySelectGui(class_3222 player) {
        super(player, 3, class_2561.method_43470("\u2756 PokeBuilder \u00b7 Party \u2756").method_27695(class_124.field_1062, class_124.field_1067));
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);

        List<Pokemon> party = CobblemonBridge.partyAsList(player);
        for (int i = 0; i < 6; i++) {
            Pokemon p = i < party.size() ? party.get(i) : null;
            safeSet(POKE_SLOTS[i], renderPokemon(p, i));
        }

        // PC toggle visibility — gated by the server-side feature flag
        // (features.pc-access defaults OFF) AND a per-player permission
        // (pokebuilder.use.pc defaults TRUE once the feature is on).
        // The permission gate uses `has` with fallback OP level 0 — i.e.
        // "everyone unless a permissions plugin explicitly denies them".
        // This matches `pokebuilder.use` (the main mod permission) and
        // means servers without LuckPerms still let players use PC
        // access once the admin opts the feature in.
        if (FeatureGate.enabled(FeatureGate.Feature.PC_ACCESS)
                && PermissionHelper.has(player, PokeBuilderConstants.PERM_USE_PC, 0)) {
            safeSet(PC_TOGGLE_SLOT, ItemBuilder.of(class_1802.field_8466)
                    .name(PokeBuilder.get().config().messages.get("gui.label.switch_to_pc").getString(),
                            class_124.field_1075, class_124.field_1067)
                    .lore("Browse and edit stored Pokémon.", class_124.field_1080)
                    .build());
        }

        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077)
                .name("Close", class_124.field_1061, class_124.field_1067).build());
    }

    private class_1799 renderPokemon(Pokemon p, int index) {
        if (p == null) {
            return ItemBuilder.of(class_1802.field_8240)
                    .name("Party Slot " + (index + 1), class_124.field_1063)
                    .lore("Empty", class_124.field_1063)
                    .build();
        }
        if (PokemonValidator.isEgg(p)) {
            return ItemBuilder.of(class_1802.field_8618)
                    .name("Egg", class_124.field_1080, class_124.field_1056)
                    .lore("Eggs cannot be modified", class_124.field_1063)
                    .build();
        }

        boolean blocked = PokemonValidator.isBlocked(p);
        boolean shiny = p.getShiny();

        // Use Cobblemon's PokemonItem to render the actual species model in
        // the slot. If the lookup fails, fall back to the Pokémon's caught
        // ball so the icon is still thematic.
        class_1799 stack = blocked
                ? new class_1799(class_1802.field_8077)
                : ModItems.pokemonIcon(p);

        Stats[] stats = CobblemonBridge.allStats();
        String ivs = String.format("%d/%d/%d/%d/%d/%d",
                p.getIvs().get(stats[0]), p.getIvs().get(stats[1]),
                p.getIvs().get(stats[2]), p.getIvs().get(stats[3]),
                p.getIvs().get(stats[4]), p.getIvs().get(stats[5]));
        String evs = String.format("%d/%d/%d/%d/%d/%d",
                p.getEvs().get(stats[0]), p.getEvs().get(stats[1]),
                p.getEvs().get(stats[2]), p.getEvs().get(stats[3]),
                p.getEvs().get(stats[4]), p.getEvs().get(stats[5]));

        class_124 nameColor = blocked ? class_124.field_1061 : (shiny ? class_124.field_1075 : class_124.field_1060);
        ItemBuilder b = ItemBuilder.of(stack)
                .name((shiny ? "\u2728 " : "") + capitalize(p.getSpecies().getName()) + "  Lv." + p.getLevel(),
                        nameColor, class_124.field_1067)
                .lore("Nature: " + capitalize(p.getNature().getName().method_12832()), class_124.field_1080)
                .lore("Ability: " + (p.getAbility() != null ? p.getAbility().getTemplate().getName() : "—"), class_124.field_1080)
                .lore("IVs: " + ivs, class_124.field_1080)
                .lore("EVs: " + evs, class_124.field_1080)
                .lore("Shiny: " + (shiny ? "Yes" : "No"), class_124.field_1080)
                .lore("Gender: " + p.getGender().name(), class_124.field_1080);

        try {
            if (p.getTeraType() != null) {
                b.lore("Tera: " + capitalize(p.getTeraType().getName()), class_124.field_1076);
            }
        } catch (Throwable ignored) {}
        try {
            int d = p.getDmaxLevel();
            if (d > 0) b.lore("Dynamax Lv.: " + d, class_124.field_1076);
        } catch (Throwable ignored) {}
        try {
            if (p.getGmaxFactor()) b.lore("G-Max Factor", class_124.field_1076);
        } catch (Throwable ignored) {}

        if (blocked) {
            b.lore("\u2716 Blocked by server rules", class_124.field_1061, class_124.field_1067);
        } else {
            b.lore("Click to edit", class_124.field_1054);
        }
        if (shiny) b.glow(true);
        return b.build();
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return "—";
        return Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase();
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (slot == CLOSE_SLOT) {
            SoundHelper.back(player);
            close();
            return;
        }
        if (slot == PC_TOGGLE_SLOT) {
            // Re-check feature + permission at click time — the toggle
            // button only renders when both are on, but gate it here
            // too in case config changed between render and click.
            if (!FeatureGate.enabled(FeatureGate.Feature.PC_ACCESS)) {
                PokeBuilder.LOGGER.debug("[PokeBuilder] PC toggle click ignored: feature disabled");
                return;
            }
            if (!PermissionHelper.has(player, PokeBuilderConstants.PERM_USE_PC, 0)) {
                PokeBuilder.LOGGER.debug("[PokeBuilder] PC toggle click ignored: player {} lacks {}",
                        player.method_5477().getString(), PokeBuilderConstants.PERM_USE_PC);
                return;
            }
            try {
                SoundHelper.selectPokemon(player);
                PokeBuilder.LOGGER.info("[PokeBuilder] Opening PC for {}", player.method_5477().getString());
                new PCSelectGui(player).open();
            } catch (Throwable t) {
                PokeBuilder.LOGGER.error("[PokeBuilder] PC toggle failed for {}: {}",
                        player.method_5477().getString(), t.toString(), t);
                player.method_7353(net.minecraft.class_2561.method_43470(
                        "Failed to open PC: " + t.getClass().getSimpleName()
                                + " — see server log").method_27692(net.minecraft.class_124.field_1061), false);
            }
            return;
        }
        for (int i = 0; i < POKE_SLOTS.length; i++) {
            if (POKE_SLOTS[i] == slot) {
                List<Pokemon> party = CobblemonBridge.partyAsList(player);
                if (i >= party.size()) return;
                Pokemon p = party.get(i);
                if (p == null || PokemonValidator.isEgg(p)) return;
                if (PokemonValidator.isBlocked(p)) {
                    player.method_7353(class_2561.method_43470("This Pokémon cannot be modified.")
                            .method_27692(class_124.field_1061), false);
                    return;
                }
                SoundHelper.selectPokemon(player);
                new EditorGui(player, p.getUuid()).open();
                return;
            }
        }
    }

    @Override
    protected void onOpen() {
        SoundHelper.openMenu(player);
    }
}
