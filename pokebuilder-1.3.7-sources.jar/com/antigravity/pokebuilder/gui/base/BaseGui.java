package com.antigravity.pokebuilder.gui.base;

import com.antigravity.pokebuilder.util.ItemBuilder;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;

public abstract class BaseGui {

    protected final class_3222 player;
    protected final int rows;
    protected final int size;
    protected final class_1277 inventory;
    protected final class_2561 title;
    protected PokeBuilderScreenHandler handler;

    protected BaseGui(class_3222 player, int rows, class_2561 title) {
        this.player = player;
        this.rows = Math.max(1, Math.min(6, rows));
        this.size = this.rows * 9;
        this.inventory = new class_1277(this.size);
        this.title = title;
    }

    public final void open() {
        try {
            build();
        } catch (Throwable t) {
            com.antigravity.pokebuilder.PokeBuilder.LOGGER.error(
                    "[PokeBuilder] GUI build failed for {} (player={}): {}",
                    getClass().getSimpleName(), player.method_5477().getString(), t.toString(), t);
            return;
        }
        // openHandledScreen closes any currently-attached screen first,
        // which fires the OLD handler's onClosed → BaseGui.onClose →
        // GuiManager.unregister(playerId). If we'd registered ourselves
        // before that point, the unregister would yank the new GUI's
        // entry too (registry is keyed by player UUID, not by gui id).
        // Open first, register after.
        player.method_17355(new net.minecraft.class_747(
                (syncId, inv, p) -> {
                    handler = new PokeBuilderScreenHandler(
                            typeForRows(rows), syncId, inv, inventory, rows, this);
                    return handler;
                }, title));
        GuiManager.register(player, this);
        try {
            onOpen();
        } catch (Throwable t) {
            com.antigravity.pokebuilder.PokeBuilder.LOGGER.warn(
                    "[PokeBuilder] GUI onOpen hook failed for {}: {}",
                    getClass().getSimpleName(), t.toString());
        }
    }

    public final void refresh() {
        inventory.method_5448();
        build();
        if (handler != null) handler.method_7623();
    }

    public final void close() {
        GuiManager.unregister(player.method_5667());
        player.method_7346();
    }

    public final void forceClose() {
        GuiManager.unregister(player.method_5667());
        try { player.method_7346(); } catch (Exception ignored) {}
    }

    public void onClose() {
        GuiManager.unregister(player.method_5667());
    }

    protected void onOpen() {}

    protected abstract void build();

    public abstract void onSlotClick(int slot, int button, class_1713 action);

    protected void fillBorders() {
        fillBorders(com.antigravity.pokebuilder.PokeBuilder.get().config().looks.borderColor);
    }

    protected void fillBorders(int color) {
        class_1799 pane = ItemBuilder.glass(color).build();
        for (int i = 0; i < 9; i++) safeSet(i, pane);
        for (int i = size - 9; i < size; i++) safeSet(i, pane);
        for (int r = 1; r < rows - 1; r++) {
            safeSet(r * 9, pane);
            safeSet(r * 9 + 8, pane);
        }
    }

    protected void fillAll(class_1799 stack) {
        for (int i = 0; i < size; i++) {
            if (inventory.method_5438(i).method_7960()) inventory.method_5447(i, stack.method_7972());
        }
    }

    protected void safeSet(int slot, class_1799 stack) {
        if (slot >= 0 && slot < size) inventory.method_5447(slot, stack);
    }

    public class_3222 player() {
        return player;
    }

    public class_1263 inventory() {
        return inventory;
    }

    private static class_3917<class_1707> typeForRows(int rows) {
        return switch (rows) {
            case 1 -> class_3917.field_18664;
            case 2 -> class_3917.field_18665;
            case 3 -> class_3917.field_17326;
            case 4 -> class_3917.field_18666;
            case 5 -> class_3917.field_18667;
            default -> class_3917.field_17327;
        };
    }

    public static final class PokeBuilderScreenHandler extends class_1707 {
        private final int guiSize;
        private final BaseGui gui;

        public PokeBuilderScreenHandler(class_3917<class_1707> type,
                                        int syncId, class_1661 playerInv, class_1263 inventory,
                                        int rows, BaseGui gui) {
            super(type, syncId, playerInv, inventory, rows);
            this.guiSize = rows * 9;
            this.gui = gui;
        }

        @Override
        public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
            if (actionType == class_1713.field_7793
                    || actionType == class_1713.field_7791
                    || actionType == class_1713.field_7796
                    || actionType == class_1713.field_7795
                    || actionType == class_1713.field_7789) {
                return;
            }

            if (slotIndex < 0 || slotIndex >= guiSize) {
                return;
            }

            if (actionType != class_1713.field_7790 && actionType != class_1713.field_7794) {
                return;
            }

            gui.onSlotClick(slotIndex, button, actionType);
        }

        @Override
        public class_1799 method_7601(class_1657 player, int index) {
            return class_1799.field_8037;
        }

        @Override
        public boolean method_7613(class_1799 stack, class_1735 slot) {
            return false;
        }

        @Override
        public boolean method_7615(class_1735 slot) {
            return false;
        }

        @Override
        public void method_7595(class_1657 player) {
            super.method_7595(player);
            gui.onClose();
        }
    }
}
