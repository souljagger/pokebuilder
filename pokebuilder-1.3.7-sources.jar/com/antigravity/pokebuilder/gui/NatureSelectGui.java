package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.gui.base.PaginatedGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.api.pokemon.Natures;
import com.cobblemon.mod.common.pokemon.Nature;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class NatureSelectGui extends PaginatedGui<Nature> {

    private final UUID pokemonId;
    private List<Nature> cached;

    public NatureSelectGui(class_3222 player, UUID pokemonId) {
        super(player, class_2561.method_43470("PokeBuilder — Nature").method_27692(class_124.field_1062));
        this.pokemonId = pokemonId;
    }

    @Override
    protected List<Nature> items() {
        if (cached != null) return cached;
        cached = new ArrayList<>();
        try {
            Collection<Nature> all = Natures.INSTANCE.all();
            cached.addAll(all);
        } catch (Throwable ignored) {}
        return cached;
    }

    @Override
    protected class_1799 renderItem(Nature nature) {
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        boolean current = p != null && p.getNature().equals(nature);
        // Nature mints from Cobblemon — naming convention: <nature>_mint.
        class_1792 icon = ModItems.natureMint(nature.getName().method_12832());
        BigDecimal cost = PokeBuilder.get().config().prices.nature;

        ItemBuilder b = ItemBuilder.of(icon)
                .name(capitalize(nature.getName().method_12832()) + " Mint", class_124.field_1075, class_124.field_1067);

        if (nature.getIncreasedStat() != null && nature.getDecreasedStat() != null
                && !nature.getIncreasedStat().equals(nature.getDecreasedStat())) {
            b.lore("+10% " + statName(nature.getIncreasedStat()), class_124.field_1060);
            b.lore("-10% " + statName(nature.getDecreasedStat()), class_124.field_1061);
        } else {
            b.lore("No stat changes", class_124.field_1080);
        }
        b.lore("Cost: " + TextHelper.formatMoney(cost) + " " + TextHelper.currencyName(), class_124.field_1054);
        if (current) b.lore("[CURRENT]", class_124.field_1060, class_124.field_1067).glow(true);
        return b.build();
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return "—";
        return Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase();
    }

    private static String statName(com.cobblemon.mod.common.api.pokemon.stats.Stat stat) {
        if (stat == null) return "";
        try {
            String id = stat.getShowdownId();
            if (id != null) return id.toLowerCase();
        } catch (Throwable ignored) {}
        try {
            return stat.getIdentifier().method_12832().toLowerCase();
        } catch (Throwable ignored) {}
        return stat.toString().toLowerCase();
    }

    @Override
    protected void onItemClick(Nature nature) {
        if (!FeatureGate.enforce(FeatureGate.Feature.NATURE, player)) { close(); return; }
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }

        BigDecimal cost = PokeBuilder.get().config().prices.nature;
        String id = nature.getName().method_12832();
        // Precheck runs inside TransactionService under the player lock —
        // catches the "already this nature" case and refunds before the
        // withdraw. The early-return above is redundant now but kept for
        // UX (skips the purchase sound on a harmless re-click).
        TransactionService.execute(player, pokemonId, FeatureGate.Feature.NATURE,
                "NATURE_SET", id, cost,
                pm -> !pm.getNature().equals(nature),
                pm -> PokemonModifier.setNature(pm, id));
        refresh();
    }

    @Override
    protected void onBack() {
        SoundHelper.back(player);
        new EditorGui(player, pokemonId).open();
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
