package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.config.PokeBuilderConfig;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.api.pokemon.stats.Stats;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class IVEditorGui extends BaseGui {

    private static final int[] HEADER_SLOTS = {10, 11, 12, 13, 14, 15};
    private static final int[] SET31_SLOTS = {19, 20, 21, 22, 23, 24};
    private static final int[] SET0_SLOTS = {28, 29, 30, 31, 32, 33};
    private static final int BACK_SLOT = 45;
    private static final int MAX_ALL_SLOT = 52;
    private static final int CLOSE_SLOT = 53;

    private final UUID pokemonId;

    public IVEditorGui(class_3222 player, UUID pokemonId) {
        super(player, 6, class_2561.method_43470("\u2756 PokeBuilder \u00b7 IVs \u2756").method_27695(class_124.field_1062, class_124.field_1067));
        this.pokemonId = pokemonId;
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }
        PokeBuilderConfig cfg = PokeBuilder.get().config();

        Stats[] stats = CobblemonBridge.allStats();
        for (int i = 0; i < 6; i++) {
            int current = p.getIvs().get(stats[i]);
            class_1792 icon = ModItems.hyperCandyFor(i);
            safeSet(HEADER_SLOTS[i], ItemBuilder.of(icon)
                    .name(CobblemonBridge.statLabel(stats[i]) + ": " + current + " / 31",
                            colorForStat(current, 31), class_124.field_1067)
                    .lore("Individual value", class_124.field_1063)
                    .glow(current == 31)
                    .build());

            boolean maxed = current >= 31;
            safeSet(SET31_SLOTS[i], ItemBuilder.of(maxed ? class_1802.field_8581 : class_1802.field_8131)
                    .name("Set to 31", maxed ? class_124.field_1063 : class_124.field_1060, class_124.field_1067)
                    .lore(maxed ? "Already maxed!" : "Cost: " + TextHelper.formatMoney(cfg.prices.iv.setSingle31) + " " + TextHelper.currencyName(),
                            maxed ? class_124.field_1060 : class_124.field_1054)
                    .glow(maxed).build());

            boolean zeroed = current <= 0;
            safeSet(SET0_SLOTS[i], ItemBuilder.of(zeroed ? class_1802.field_8879 : class_1802.field_8264)
                    .name("Set to 0", zeroed ? class_124.field_1063 : class_124.field_1061, class_124.field_1067)
                    .lore(zeroed ? "Already zero" : "Cost: " + TextHelper.formatMoney(cfg.prices.iv.setSingle0) + " " + TextHelper.currencyName(),
                            zeroed ? class_124.field_1060 : class_124.field_1054)
                    .build());
        }

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        if (PokeBuilder.get().config().features.ivMaxAll) {
            safeSet(MAX_ALL_SLOT, ItemBuilder.of(ModItems.rareCandy())
                    .name("Max All IVs", class_124.field_1075, class_124.field_1067)
                    .lore("Cost: " + TextHelper.formatMoney(cfg.prices.iv.maxAll) + " " + TextHelper.currencyName(), class_124.field_1054)
                    .build());
        }
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (slot == BACK_SLOT) { SoundHelper.back(player); new EditorGui(player, pokemonId).open(); return; }
        if (slot == CLOSE_SLOT) { close(); return; }
        if (!FeatureGate.enforce(FeatureGate.Feature.IV_EDITOR, player)) { close(); return; }
        if (slot == MAX_ALL_SLOT) {
            if (!FeatureGate.enforce(FeatureGate.Feature.IV_MAX_ALL, player)) return;
            BigDecimal cost = PokeBuilder.get().config().prices.iv.maxAll;
            TransactionService.execute(player, pokemonId, FeatureGate.Feature.IV_MAX_ALL,
                    "IV_MAX_ALL", "all31", cost,
                    // Precheck: skip the withdraw if every IV is already 31.
                    // Prior to v1.4 clicking "Max All" on a perfect mon would
                    // burn the price every click with no change.
                    p -> {
                        for (Stats s : CobblemonBridge.allStats()) {
                            if (p.getIvs().get(s) < 31) return true;
                        }
                        return false;
                    },
                    PokemonModifier::maxAllIvs);
            refresh();
            return;
        }

        Stats[] stats = CobblemonBridge.allStats();
        for (int i = 0; i < 6; i++) {
            if (SET31_SLOTS[i] == slot) {
                final Stats s = stats[i];
                BigDecimal cost = PokeBuilder.get().config().prices.iv.setSingle31;
                TransactionService.execute(player, pokemonId, FeatureGate.Feature.IV_EDITOR,
                        "IV_SET_31", CobblemonBridge.statLabel(s), cost,
                        p -> p.getIvs().get(s) < 31,
                        p -> PokemonModifier.setIv(p, s, 31));
                refresh();
                return;
            }
            if (SET0_SLOTS[i] == slot) {
                final Stats s = stats[i];
                BigDecimal cost = PokeBuilder.get().config().prices.iv.setSingle0;
                TransactionService.execute(player, pokemonId, FeatureGate.Feature.IV_EDITOR,
                        "IV_SET_0", CobblemonBridge.statLabel(s), cost,
                        p -> p.getIvs().get(s) > 0,
                        p -> PokemonModifier.setIv(p, s, 0));
                refresh();
                return;
            }
        }
    }

    private static class_124 colorForStat(int value, int max) {
        if (value >= max) return class_124.field_1060;
        if (value >= max * 3 / 4) return class_124.field_1075;
        if (value >= max / 2) return class_124.field_1054;
        if (value > 0) return class_124.field_1065;
        return class_124.field_1061;
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
