package com.antigravity.pokebuilder.gui.admin;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.admin.ChatInputManager;
import com.antigravity.pokebuilder.config.PokeBuilderConfig;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.SoundHelper;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

public class RestrictionsAdminGui extends BaseGui {

    private static final int LEGENDARY_SLOT = 10;
    private static final int MYTHICAL_SLOT = 12;
    private static final int ULTRA_SLOT = 14;
    private static final int PARADOX_SLOT = 16;
    private static final int BLOCKED_LIST_SLOT = 22;
    private static final int ADD_SPECIES_SLOT = 29;
    private static final int REMOVE_SPECIES_SLOT = 31;
    private static final int CLEAR_SPECIES_SLOT = 33;
    private static final int BACK_SLOT = 45;
    private static final int CLOSE_SLOT = 53;

    public RestrictionsAdminGui(class_3222 player) {
        super(player, 6, PokeBuilder.get().config().messages.get("gui.title.admin.restrictions"));
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);
        PokeBuilderConfig.Restrictions r = PokeBuilder.get().config().restrictions;

        safeSet(LEGENDARY_SLOT, toggle("Block legendaries", r.blockLegendaries));
        safeSet(MYTHICAL_SLOT, toggle("Block mythicals", r.blockMythicals));
        safeSet(ULTRA_SLOT, toggle("Block ultra beasts", r.blockUltraBeasts));
        safeSet(PARADOX_SLOT, toggle("Block paradox", r.blockParadox));

        ItemBuilder list = ItemBuilder.of(class_1802.field_8529)
                .name("Blocked species (" + r.blockedSpecies.size() + ")", class_124.field_1065, class_124.field_1067);
        if (r.blockedSpecies.isEmpty()) {
            list.lore("(none)", class_124.field_1063);
        } else {
            int shown = 0;
            for (String sp : r.blockedSpecies) {
                if (shown++ >= 8) { list.lore("... and " + (r.blockedSpecies.size() - 8) + " more", class_124.field_1063); break; }
                list.lore("- " + sp, class_124.field_1080);
            }
        }
        safeSet(BLOCKED_LIST_SLOT, list.build());

        safeSet(ADD_SPECIES_SLOT, ItemBuilder.of(class_1802.field_8839)
                .name("Add species", class_124.field_1060, class_124.field_1067)
                .lore("Click → type name in chat", class_124.field_1080).build());
        safeSet(REMOVE_SPECIES_SLOT, ItemBuilder.of(class_1802.field_8197)
                .name("Remove species", class_124.field_1061, class_124.field_1067)
                .lore("Click → type name in chat", class_124.field_1080).build());
        safeSet(CLEAR_SPECIES_SLOT, ItemBuilder.of(class_1802.field_8626)
                .name("Clear ALL", class_124.field_1079, class_124.field_1067)
                .lore("Shift-click to confirm", class_124.field_1080).build());

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
    }

    private net.minecraft.class_1799 toggle(String label, boolean on) {
        return ItemBuilder.of(on ? class_1802.field_19049 : class_1802.field_19058)
                .name(label + ": " + (on ? "YES" : "NO"), on ? class_124.field_1060 : class_124.field_1061, class_124.field_1067)
                .lore("Click to toggle", class_124.field_1080).build();
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (!AdminUtils.isAdmin(player)) { close(); return; }
        PokeBuilderConfig.Restrictions r = PokeBuilder.get().config().restrictions;
        boolean shift = action == class_1713.field_7794;

        switch (slot) {
            case LEGENDARY_SLOT -> {
                r.blockLegendaries = !r.blockLegendaries;
                AdminUtils.logAdmin(player, "restrictions.blockLegendaries", String.valueOf(!r.blockLegendaries), String.valueOf(r.blockLegendaries));
            }
            case MYTHICAL_SLOT -> {
                r.blockMythicals = !r.blockMythicals;
                AdminUtils.logAdmin(player, "restrictions.blockMythicals", String.valueOf(!r.blockMythicals), String.valueOf(r.blockMythicals));
            }
            case ULTRA_SLOT -> {
                r.blockUltraBeasts = !r.blockUltraBeasts;
                AdminUtils.logAdmin(player, "restrictions.blockUltraBeasts", String.valueOf(!r.blockUltraBeasts), String.valueOf(r.blockUltraBeasts));
            }
            case PARADOX_SLOT -> {
                r.blockParadox = !r.blockParadox;
                AdminUtils.logAdmin(player, "restrictions.blockParadox", String.valueOf(!r.blockParadox), String.valueOf(r.blockParadox));
            }
            case ADD_SPECIES_SLOT -> {
                ChatInputManager.request(player, "Species to BLOCK",
                        text -> {
                            String name = text.toLowerCase().trim();
                            if (!name.isEmpty() && !r.blockedSpecies.contains(name)) {
                                r.blockedSpecies.add(name);
                                AdminUtils.logAdmin(player, "restrictions.blockedSpecies[+]", "-", name);
                            }
                            new RestrictionsAdminGui(player).open();
                        },
                        () -> new RestrictionsAdminGui(player).open());
                close();
                return;
            }
            case REMOVE_SPECIES_SLOT -> {
                ChatInputManager.request(player, "Species to UNBLOCK",
                        text -> {
                            String name = text.toLowerCase().trim();
                            if (r.blockedSpecies.remove(name)) {
                                AdminUtils.logAdmin(player, "restrictions.blockedSpecies[-]", name, "-");
                            }
                            new RestrictionsAdminGui(player).open();
                        },
                        () -> new RestrictionsAdminGui(player).open());
                close();
                return;
            }
            case CLEAR_SPECIES_SLOT -> {
                if (!shift) {
                    player.method_7353(net.minecraft.class_2561.method_43470("Shift-click to confirm clear.").method_27692(class_124.field_1054), false);
                    return;
                }
                int n = r.blockedSpecies.size();
                r.blockedSpecies.clear();
                AdminUtils.logAdmin(player, "restrictions.blockedSpecies[clear]", String.valueOf(n), "0");
            }
            case BACK_SLOT -> { SoundHelper.back(player); new AdminGui(player).open(); return; }
            case CLOSE_SLOT -> { close(); return; }
            default -> { return; }
        }
        SoundHelper.openMenu(player);
        refresh();
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
