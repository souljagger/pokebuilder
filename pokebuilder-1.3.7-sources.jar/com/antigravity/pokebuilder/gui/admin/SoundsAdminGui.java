package com.antigravity.pokebuilder.gui.admin;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.config.PokeBuilderConfig;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.SoundHelper;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

public class SoundsAdminGui extends BaseGui {

    private static final int ENABLED_SLOT = 11;
    private static final int VOLUME_SLOT = 20;
    private static final int VOLUME_MINUS = 21;
    private static final int VOLUME_PLUS = 22;
    private static final int PITCH_SLOT = 29;
    private static final int PITCH_MINUS = 30;
    private static final int PITCH_PLUS = 31;
    private static final int BACK_SLOT = 45;
    private static final int CLOSE_SLOT = 53;

    public SoundsAdminGui(class_3222 player) {
        super(player, 6, PokeBuilder.get().config().messages.get("gui.title.admin.sounds"));
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);
        PokeBuilderConfig.Sounds s = PokeBuilder.get().config().sounds;

        safeSet(ENABLED_SLOT, ItemBuilder.of(s.enabled ? class_1802.field_8643 : class_1802.field_8077)
                .name("Sounds: " + (s.enabled ? "ON" : "OFF"),
                        s.enabled ? class_124.field_1060 : class_124.field_1061, class_124.field_1067)
                .lore("Click to toggle", class_124.field_1080).build());

        safeSet(VOLUME_SLOT, ItemBuilder.of(class_1802.field_8565)
                .name(String.format("Volume: %.2f", s.volume), class_124.field_1065, class_124.field_1067)
                .lore("Range 0.00 - 2.00", class_124.field_1080).build());
        safeSet(VOLUME_MINUS, ItemBuilder.of(class_1802.field_8197).name("-0.10 (shift -0.50)", class_124.field_1061).build());
        safeSet(VOLUME_PLUS, ItemBuilder.of(class_1802.field_8839).name("+0.10 (shift +0.50)", class_124.field_1060).build());

        safeSet(PITCH_SLOT, ItemBuilder.of(class_1802.field_16315)
                .name(String.format("Pitch: %.2f", s.pitch), class_124.field_1065, class_124.field_1067)
                .lore("Range 0.50 - 2.00", class_124.field_1080).build());
        safeSet(PITCH_MINUS, ItemBuilder.of(class_1802.field_8197).name("-0.10 (shift -0.50)", class_124.field_1061).build());
        safeSet(PITCH_PLUS, ItemBuilder.of(class_1802.field_8839).name("+0.10 (shift +0.50)", class_124.field_1060).build());

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (!AdminUtils.isAdmin(player)) { close(); return; }
        PokeBuilderConfig.Sounds s = PokeBuilder.get().config().sounds;
        boolean shift = action == class_1713.field_7794;
        float step = shift ? 0.50f : 0.10f;

        switch (slot) {
            case ENABLED_SLOT -> {
                s.enabled = !s.enabled;
                AdminUtils.logAdmin(player, "sounds.enabled", String.valueOf(!s.enabled), String.valueOf(s.enabled));
            }
            case VOLUME_MINUS -> {
                float old = s.volume;
                s.volume = AdminUtils.clampFloat(s.volume - step, 0f, 2f);
                AdminUtils.logAdmin(player, "sounds.volume", String.valueOf(old), String.valueOf(s.volume));
            }
            case VOLUME_PLUS -> {
                float old = s.volume;
                s.volume = AdminUtils.clampFloat(s.volume + step, 0f, 2f);
                AdminUtils.logAdmin(player, "sounds.volume", String.valueOf(old), String.valueOf(s.volume));
            }
            case PITCH_MINUS -> {
                float old = s.pitch;
                s.pitch = AdminUtils.clampFloat(s.pitch - step, 0.5f, 2f);
                AdminUtils.logAdmin(player, "sounds.pitch", String.valueOf(old), String.valueOf(s.pitch));
            }
            case PITCH_PLUS -> {
                float old = s.pitch;
                s.pitch = AdminUtils.clampFloat(s.pitch + step, 0.5f, 2f);
                AdminUtils.logAdmin(player, "sounds.pitch", String.valueOf(old), String.valueOf(s.pitch));
            }
            case BACK_SLOT -> { SoundHelper.back(player); new AdminGui(player).open(); return; }
            case CLOSE_SLOT -> { close(); return; }
            default -> { return; }
        }
        SoundHelper.openMenu(player);
        refresh();
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
