package com.antigravity.pokebuilder.gui.admin;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.config.PokeBuilderConfig;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.SoundHelper;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_3222;

public class SecurityAdminGui extends BaseGui {

    private static final int COOLDOWN_SLOT = 11;
    private static final int COOLDOWN_MINUS = 12;
    private static final int COOLDOWN_PLUS = 13;
    private static final int RATE_SLOT = 20;
    private static final int RATE_MINUS = 21;
    private static final int RATE_PLUS = 22;
    private static final int CREATIVE_SLOT = 29;
    private static final int FAINTED_SLOT = 31;
    private static final int BYPASS_GATE_SLOT = 33;
    private static final int BACK_SLOT = 45;
    private static final int CLOSE_SLOT = 53;

    public SecurityAdminGui(class_3222 player) {
        super(player, 6, PokeBuilder.get().config().messages.get("gui.title.admin.security"));
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);
        PokeBuilderConfig.Security s = PokeBuilder.get().config().security;

        safeSet(COOLDOWN_SLOT, ItemBuilder.of(class_1802.field_8557)
                .name("Click cooldown: " + s.clickCooldownMs + " ms", class_124.field_1065, class_124.field_1067)
                .lore("Min 100, max 5000", class_124.field_1080).build());
        safeSet(COOLDOWN_MINUS, stepper(false, "-100 ms (shift -500)"));
        safeSet(COOLDOWN_PLUS, stepper(true, "+100 ms (shift +500)"));

        safeSet(RATE_SLOT, ItemBuilder.of(class_1802.field_8619)
                .name("Max mods/min: " + s.maxModificationsPerMinute, class_124.field_1065, class_124.field_1067)
                .lore("Min 1, max 1000", class_124.field_1080).build());
        safeSet(RATE_MINUS, stepper(false, "-1 (shift -10)"));
        safeSet(RATE_PLUS, stepper(true, "+1 (shift +10)"));

        safeSet(CREATIVE_SLOT, ItemBuilder.of(s.allowCreativeMode ? class_1802.field_19049 : class_1802.field_19058)
                .name("Allow creative mode: " + (s.allowCreativeMode ? "YES" : "NO"),
                        s.allowCreativeMode ? class_124.field_1060 : class_124.field_1061, class_124.field_1067)
                .lore("Click to toggle", class_124.field_1080).build());

        safeSet(FAINTED_SLOT, ItemBuilder.of(s.allowFaintedPokemon ? class_1802.field_19049 : class_1802.field_19058)
                .name("Allow fainted Pokémon: " + (s.allowFaintedPokemon ? "YES" : "NO"),
                        s.allowFaintedPokemon ? class_124.field_1060 : class_124.field_1061, class_124.field_1067)
                .lore("Click to toggle", class_124.field_1080).build());

        // Master gate for the bypass.* permission family. Default OFF
        // — even if LuckPerms grants the bypass node (e.g. via a
        // wildcard like `pokebuilder.*` on an admin group), the
        // transaction layer treats it as not-granted unless this is on.
        safeSet(BYPASS_GATE_SLOT, ItemBuilder.of(s.allowBypassPermissions ? class_1802.field_19049 : class_1802.field_19058)
                .name("Allow bypass perms: " + (s.allowBypassPermissions ? "YES" : "NO"),
                        s.allowBypassPermissions ? class_124.field_1054 : class_124.field_1060, class_124.field_1067)
                .lore("Master gate for pokebuilder.bypass.*", class_124.field_1080)
                .lore(s.allowBypassPermissions
                        ? "↑ ON: anyone with the perm bypasses cost/cooldown"
                        : "↓ OFF: bypass perms are ignored (safe default)",
                        s.allowBypassPermissions ? class_124.field_1054 : class_124.field_1060)
                .lore("Click to toggle", class_124.field_1080).build());

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
    }

    private net.minecraft.class_1799 stepper(boolean plus, String label) {
        return ItemBuilder.of(plus ? class_1802.field_8839 : class_1802.field_8197)
                .name(label, plus ? class_124.field_1060 : class_124.field_1061, class_124.field_1067).build();
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (!AdminUtils.isAdmin(player)) { close(); return; }
        PokeBuilderConfig.Security s = PokeBuilder.get().config().security;
        boolean shift = action == class_1713.field_7794;

        switch (slot) {
            case COOLDOWN_MINUS -> {
                long old = s.clickCooldownMs;
                s.clickCooldownMs = AdminUtils.clampLong(s.clickCooldownMs - (shift ? 500 : 100), 100, 5000);
                AdminUtils.logAdmin(player, "security.clickCooldownMs", String.valueOf(old), String.valueOf(s.clickCooldownMs));
            }
            case COOLDOWN_PLUS -> {
                long old = s.clickCooldownMs;
                s.clickCooldownMs = AdminUtils.clampLong(s.clickCooldownMs + (shift ? 500 : 100), 100, 5000);
                AdminUtils.logAdmin(player, "security.clickCooldownMs", String.valueOf(old), String.valueOf(s.clickCooldownMs));
            }
            case RATE_MINUS -> {
                int old = s.maxModificationsPerMinute;
                s.maxModificationsPerMinute = AdminUtils.clampInt(s.maxModificationsPerMinute - (shift ? 10 : 1), 1, 1000);
                AdminUtils.logAdmin(player, "security.maxModificationsPerMinute", String.valueOf(old), String.valueOf(s.maxModificationsPerMinute));
            }
            case RATE_PLUS -> {
                int old = s.maxModificationsPerMinute;
                s.maxModificationsPerMinute = AdminUtils.clampInt(s.maxModificationsPerMinute + (shift ? 10 : 1), 1, 1000);
                AdminUtils.logAdmin(player, "security.maxModificationsPerMinute", String.valueOf(old), String.valueOf(s.maxModificationsPerMinute));
            }
            case CREATIVE_SLOT -> {
                s.allowCreativeMode = !s.allowCreativeMode;
                AdminUtils.logAdmin(player, "security.allowCreativeMode", String.valueOf(!s.allowCreativeMode), String.valueOf(s.allowCreativeMode));
            }
            case FAINTED_SLOT -> {
                s.allowFaintedPokemon = !s.allowFaintedPokemon;
                AdminUtils.logAdmin(player, "security.allowFaintedPokemon", String.valueOf(!s.allowFaintedPokemon), String.valueOf(s.allowFaintedPokemon));
            }
            case BYPASS_GATE_SLOT -> {
                s.allowBypassPermissions = !s.allowBypassPermissions;
                AdminUtils.logAdmin(player, "security.allowBypassPermissions",
                        String.valueOf(!s.allowBypassPermissions), String.valueOf(s.allowBypassPermissions));
            }
            case BACK_SLOT -> { SoundHelper.back(player); new AdminGui(player).open(); return; }
            case CLOSE_SLOT -> { close(); return; }
            default -> { return; }
        }
        SoundHelper.openMenu(player);
        refresh();
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
