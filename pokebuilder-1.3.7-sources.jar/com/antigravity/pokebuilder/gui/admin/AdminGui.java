package com.antigravity.pokebuilder.gui.admin;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.SoundHelper;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class AdminGui extends BaseGui {

    private static final int PRICES_SLOT = 10;
    private static final int FEATURES_SLOT = 11;
    private static final int SECURITY_SLOT = 13;
    private static final int RESTRICTIONS_SLOT = 15;
    private static final int SOUNDS_SLOT = 16;
    private static final int MESSAGES_SLOT = 22;
    private static final int SAVE_SLOT = 40;
    private static final int RELOAD_SLOT = 42;
    private static final int CLOSE_SLOT = 49;

    public AdminGui(class_3222 player) {
        super(player, 6, PokeBuilder.get().config().messages.get("gui.title.admin"));
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);

        // Banner header across slot 4
        safeSet(4, ItemBuilder.of(class_1802.field_8137)
                .name("\u2756 Admin Control Panel \u2756", class_124.field_1065, class_124.field_1067)
                .lore("Live-edit every PokeBuilder setting", class_124.field_1080)
                .lore("Click SAVE TO DISK to persist", class_124.field_1063)
                .glow(true).build());

        safeSet(PRICES_SLOT, ItemBuilder.of(class_1802.field_8695)
                .name("Prices", class_124.field_1065, class_124.field_1067)
                .lore("Adjust every cost (+/- buttons)", class_124.field_1080)
                .lore("Shift-click for x10 steps", class_124.field_1063).build());

        safeSet(FEATURES_SLOT, ItemBuilder.of(ModItems.linkCable())
                .name("Features", class_124.field_1075, class_124.field_1067)
                .lore("Enable / disable individual purchases", class_124.field_1080)
                .lore("Disabled features are hidden from /pb", class_124.field_1063)
                .build());

        safeSet(SECURITY_SLOT, ItemBuilder.of(class_1802.field_8076)
                .name("Security", class_124.field_1061, class_124.field_1067)
                .lore("Cooldown, rate limit, creative", class_124.field_1080)
                .lore("Fainted-Pokémon allow toggle", class_124.field_1063)
                .build());

        safeSet(RESTRICTIONS_SLOT, ItemBuilder.of(class_1802.field_22421)
                .name("Restrictions", class_124.field_1079, class_124.field_1067)
                .lore("Legendary / Mythical / Ultra Beast", class_124.field_1080)
                .lore("Paradox toggle + blocked species list", class_124.field_1063)
                .build());

        safeSet(SOUNDS_SLOT, ItemBuilder.of(class_1802.field_8643)
                .name("Sounds", class_124.field_1075, class_124.field_1067)
                .lore("Enable / volume / pitch", class_124.field_1080).build());

        safeSet(MESSAGES_SLOT, ItemBuilder.of(class_1802.field_8674)
                .name("Messages", class_124.field_1076, class_124.field_1067)
                .lore("Edit every user-facing string", class_124.field_1080)
                .lore("Click, then type in chat", class_124.field_1063).build());

        boolean dirty = PokeBuilder.get().isDirty();
        safeSet(SAVE_SLOT, ItemBuilder.of(dirty ? class_1802.field_8839 : class_1802.field_8340)
                .name("SAVE TO DISK", class_124.field_1060, class_124.field_1067)
                .lore(dirty ? "\u26a0 You have unsaved changes" : "Nothing to save",
                        dirty ? class_124.field_1054 : class_124.field_1063)
                .lore("Writes config.conf atomically", class_124.field_1063)
                .glow(dirty).build());

        safeSet(RELOAD_SLOT, ItemBuilder.of(class_1802.field_8529)
                .name("RELOAD FROM DISK", class_124.field_1075, class_124.field_1067)
                .lore("Re-reads config.conf from disk", class_124.field_1080)
                .lore("Unsaved in-memory edits will be lost", class_124.field_1061)
                .build());

        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077)
                .name("Close", class_124.field_1061, class_124.field_1067).build());
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (!AdminUtils.isAdmin(player)) { close(); return; }

        switch (slot) {
            case PRICES_SLOT -> new PricesAdminGui(player).open();
            case FEATURES_SLOT -> new FeaturesAdminGui(player).open();
            case SECURITY_SLOT -> new SecurityAdminGui(player).open();
            case RESTRICTIONS_SLOT -> new RestrictionsAdminGui(player).open();
            case SOUNDS_SLOT -> new SoundsAdminGui(player).open();
            case MESSAGES_SLOT -> new MessagesAdminGui(player).open();
            case SAVE_SLOT -> {
                if (PokeBuilder.get().saveConfig()) {
                    player.method_7353(PokeBuilder.get().config().messages.get("command.saved"), false);
                    SoundHelper.purchaseSuccess(player);
                } else {
                    player.method_7353(PokeBuilder.get().config().messages.get("command.save_failed"), false);
                    SoundHelper.purchaseFailed(player);
                }
                refresh();
            }
            case RELOAD_SLOT -> {
                PokeBuilder.get().reloadConfig();
                player.method_7353(PokeBuilder.get().config().messages.get("command.reloaded"), false);
                SoundHelper.openMenu(player);
                refresh();
            }
            case CLOSE_SLOT -> close();
            default -> {}
        }
    }

    @Override
    protected void onOpen() {
        SoundHelper.openMenu(player);
    }

    static class_2561 title(String key) {
        return PokeBuilder.get().config().messages.get(key);
    }
}
