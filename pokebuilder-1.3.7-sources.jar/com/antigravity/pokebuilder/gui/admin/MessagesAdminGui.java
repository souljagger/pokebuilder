package com.antigravity.pokebuilder.gui.admin;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.admin.ChatInputManager;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.messages.PokeBuilderMessages;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.SoundHelper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class MessagesAdminGui extends BaseGui {

    private static final int PER_PAGE = 28;
    private static final int BACK_SLOT = 45;
    private static final int PREV_SLOT = 48;
    private static final int PAGE_SLOT = 49;
    private static final int NEXT_SLOT = 50;
    private static final int CLOSE_SLOT = 53;

    private int page = 0;
    private final List<String> keys;

    public MessagesAdminGui(class_3222 player) {
        super(player, 6, PokeBuilder.get().config().messages.get("gui.title.admin.messages"));
        this.keys = new ArrayList<>(PokeBuilder.get().config().messages.all().keySet());
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);
        PokeBuilderMessages msgs = PokeBuilder.get().config().messages;

        int totalPages = Math.max(1, (int) Math.ceil(keys.size() / (double) PER_PAGE));
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0;

        int start = page * PER_PAGE;
        int end = Math.min(start + PER_PAGE, keys.size());

        int[] slots = contentSlots();
        for (int i = start; i < end; i++) {
            String key = keys.get(i);
            String raw = msgs.raw(key);
            String preview = raw.length() > 40 ? raw.substring(0, 37) + "..." : raw;

            safeSet(slots[i - start], ItemBuilder.of(class_1802.field_8674)
                    .name(key, class_124.field_1065, class_124.field_1067)
                    .lore(preview, class_124.field_1080)
                    .lore("Left-click → edit in chat", class_124.field_1054)
                    .lore("Right-click → reset to default", class_124.field_1061)
                    .build());
        }

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        if (page > 0) safeSet(PREV_SLOT, ItemBuilder.of(class_1802.field_8236).name("Previous", class_124.field_1075).build());
        if (page < totalPages - 1) safeSet(NEXT_SLOT, ItemBuilder.of(class_1802.field_8236).name("Next", class_124.field_1075).build());
        safeSet(PAGE_SLOT, ItemBuilder.of(class_1802.field_8407).name("Page " + (page + 1) + " / " + totalPages, class_124.field_1068).build());
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
    }

    private int[] contentSlots() {
        int[] s = new int[PER_PAGE];
        int idx = 0;
        for (int row = 0; row < 4; row++) {
            for (int col = 1; col < 8; col++) {
                s[idx++] = (row + 1) * 9 + col;
            }
        }
        return s;
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (!AdminUtils.isAdmin(player)) { close(); return; }
        if (slot == BACK_SLOT) { SoundHelper.back(player); new AdminGui(player).open(); return; }
        if (slot == CLOSE_SLOT) { close(); return; }
        if (slot == PREV_SLOT && page > 0) { page--; refresh(); return; }
        if (slot == NEXT_SLOT) { page++; refresh(); return; }

        int[] slots = contentSlots();
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == slot) {
                int idx = page * PER_PAGE + i;
                if (idx >= keys.size()) return;
                String key = keys.get(idx);

                if (button == 1) {
                    // Drop the override so the key falls through to the
                    // active locale's JSON base. Previously this
                    // constructed a fresh PokeBuilderMessages and copied
                    // its value back in, which hardcoded English even on
                    // a non-en_us server.
                    PokeBuilderMessages msgs = PokeBuilder.get().config().messages;
                    String old = msgs.raw(key);
                    msgs.resetToDefault(key);
                    String def = msgs.raw(key);
                    AdminUtils.logAdmin(player, "messages[" + key + "]", old, def);
                    SoundHelper.openMenu(player);
                    refresh();
                    return;
                }

                ChatInputManager.request(player, key,
                        text -> {
                            String old = PokeBuilder.get().config().messages.raw(key);
                            PokeBuilder.get().config().messages.put(key, text);
                            AdminUtils.logAdmin(player, "messages[" + key + "]", old, text);
                            player.method_7353(class_2561.method_43470("Applied: ").method_27692(class_124.field_1060)
                                    .method_10852(PokeBuilderMessages.colorize(text)), false);
                            new MessagesAdminGui(player).open();
                        },
                        () -> new MessagesAdminGui(player).open());
                close();
                return;
            }
        }
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
