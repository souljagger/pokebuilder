package com.antigravity.pokebuilder.util;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9296;
import net.minecraft.class_9334;

public final class HeadTextureHelper {

    private HeadTextureHelper() {}

    public static class_1799 skullWithTexture(String base64Texture) {
        class_1799 skull = new class_1799(class_1802.field_8575);
        if (base64Texture == null || base64Texture.isBlank()) return skull;

        try {
            GameProfile profile = new GameProfile(UUID.randomUUID(), "PokeBuilderHead");
            profile.getProperties().put("textures", new Property("textures", base64Texture));
            skull.method_57379(class_9334.field_49617, new class_9296(profile));
        } catch (Throwable ignored) {}
        return skull;
    }

    public static class_1799 fallback() {
        return new class_1799(class_1802.field_8575);
    }
}
