package com.antigravity.pokebuilder.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public final class ItemBuilder {

    private final class_1799 stack;
    private final List<class_2561> lore = new ArrayList<>();

    private ItemBuilder(class_1799 stack) {
        this.stack = stack;
    }

    public static ItemBuilder of(net.minecraft.class_1792 item) {
        return new ItemBuilder(new class_1799(item));
    }

    public static ItemBuilder of(class_1799 stack) {
        return new ItemBuilder(stack.method_7972());
    }

    public static ItemBuilder glass(int dyeColor) {
        net.minecraft.class_1792 pane = switch (dyeColor) {
            case 3 -> class_1802.field_8196;
            case 5 -> class_1802.field_8581;
            case 7 -> class_1802.field_8871;
            case 10 -> class_1802.field_8739;
            case 14 -> class_1802.field_8879;
            case 15 -> class_1802.field_8157;
            default -> class_1802.field_8871;
        };
        return of(pane).name(class_2561.method_43470(" "));
    }

    public ItemBuilder name(class_2561 text) {
        class_5250 unitalic = class_2561.method_43473().method_10852(text).method_27694(s -> s.method_10978(false));
        stack.method_57379(class_9334.field_49631, unitalic);
        return this;
    }

    public ItemBuilder name(String text, class_124... fmt) {
        // Text.literal(null) NPEs on Minecraft 1.21+ — coerce to empty
        // string so a stray null upstream doesn't crash the whole GUI.
        class_5250 t = class_2561.method_43470(text == null ? "" : text);
        for (class_124 f : fmt) t = t.method_27692(f);
        return name(t);
    }

    public ItemBuilder lore(class_2561 line) {
        if (line == null) return this;
        class_5250 unitalic = class_2561.method_43473().method_10852(line).method_27694(s -> s.method_10978(false));
        lore.add(unitalic);
        return this;
    }

    public ItemBuilder lore(String line, class_124... fmt) {
        // Same null-coercion as name(): a null lore line means "skip
        // this lore entry", not "crash the GUI".
        if (line == null) return this;
        class_5250 t = class_2561.method_43470(line);
        for (class_124 f : fmt) t = t.method_27692(f);
        return lore(t);
    }

    public ItemBuilder lore(Collection<class_2561> lines) {
        for (class_2561 l : lines) lore(l);
        return this;
    }

    public ItemBuilder loreLines(String... lines) {
        for (String line : Arrays.asList(lines)) lore(line, class_124.field_1080);
        return this;
    }

    public ItemBuilder glow(boolean glow) {
        if (glow) {
            stack.method_57379(class_9334.field_49641, true);
        }
        return this;
    }

    public ItemBuilder count(int count) {
        stack.method_7939(Math.max(1, Math.min(64, count)));
        return this;
    }

    public class_1799 build() {
        if (!lore.isEmpty()) {
            stack.method_57379(class_9334.field_49632, new class_9290(new ArrayList<>(lore)));
        }
        return stack;
    }
}
