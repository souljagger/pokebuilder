package com.antigravity.pokebuilder.util;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.economy.EconomyHandler;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import java.math.BigDecimal;
import java.text.DecimalFormat;

public final class TextHelper {

    private TextHelper() {}

    public static class_2561 plain(String s) {
        return class_2561.method_43470(s);
    }

    public static class_2561 colored(String s, class_124... fmt) {
        class_5250 t = class_2561.method_43470(s);
        for (class_124 f : fmt) t = t.method_27692(f);
        return t;
    }

    public static class_2561 gray(String s) {
        return colored(s, class_124.field_1080);
    }

    public static class_2561 gold(String s) {
        return colored(s, class_124.field_1065);
    }

    public static class_2561 red(String s) {
        return colored(s, class_124.field_1061);
    }

    public static class_2561 green(String s) {
        return colored(s, class_124.field_1060);
    }

    public static String formatMoney(BigDecimal amount) {
        String fmt = PokeBuilder.get().config().economy.format;
        try {
            return new DecimalFormat(fmt).format(amount);
        } catch (Exception e) {
            return amount.toPlainString();
        }
    }

    public static String currencyName() {
        String override = PokeBuilder.get().config().economy.displayName;
        if (override != null && !override.isBlank()) return override;
        try {
            if (EconomyHandler.currency() != null) {
                Component plural = EconomyHandler.currency().plural();
                if (plural != null) {
                    return PlainTextComponentSerializer.plainText().serialize(plural);
                }
            }
        } catch (Throwable ignored) {}
        return "coins";
    }
}
