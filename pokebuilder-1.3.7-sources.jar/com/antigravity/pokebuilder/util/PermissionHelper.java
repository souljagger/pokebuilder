package com.antigravity.pokebuilder.util;

import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_3222;

public final class PermissionHelper {

    private PermissionHelper() {}

    public static boolean has(class_2168 src, String node, int fallbackOpLevel) {
        try {
            return Permissions.check(src, node, fallbackOpLevel);
        } catch (Throwable t) {
            return src.method_9259(fallbackOpLevel);
        }
    }

    public static boolean has(class_3222 player, String node, int fallbackOpLevel) {
        try {
            return Permissions.check(player, node, fallbackOpLevel);
        } catch (Throwable t) {
            return player.method_5687(fallbackOpLevel);
        }
    }

    // Bypass / opt-in nodes: default must be "nobody" unless a permission
    // provider explicitly grants it. Do NOT fall back to OP level here —
    // otherwise every /op'd player silently bypasses costs and cooldowns.
    public static boolean hasExplicit(class_3222 player, String node) {
        try {
            return Permissions.check(player, node, false);
        } catch (Throwable t) {
            return false;
        }
    }
}
