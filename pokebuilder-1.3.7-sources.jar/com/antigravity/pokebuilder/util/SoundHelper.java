package com.antigravity.pokebuilder.util;

import com.antigravity.pokebuilder.PokeBuilder;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public final class SoundHelper {

    private SoundHelper() {}

    public static void play(class_3222 player, class_3414 sound) {
        var cfg = PokeBuilder.get().config().sounds;
        if (!cfg.enabled) return;
        player.method_17356(sound, class_3419.field_15250, cfg.volume, cfg.pitch);
    }

    public static void openMenu(class_3222 p) { play(p, class_3417.field_15015.comp_349()); }
    public static void selectPokemon(class_3222 p) { play(p, class_3417.field_14627); }
    public static void purchaseSuccess(class_3222 p) { play(p, class_3417.field_14709); }
    public static void purchaseFailed(class_3222 p) { play(p, class_3417.field_15008); }
    public static void shinyOn(class_3222 p) { play(p, class_3417.field_14709); }
    public static void shinyOff(class_3222 p) { play(p, class_3417.field_15102); }
    public static void back(class_3222 p) { play(p, class_3417.field_15015.comp_349()); }
}
