package com.antigravity.pokebuilder.util;

import com.cobblemon.mod.common.item.PokemonItem;
import com.cobblemon.mod.common.pokeball.PokeBall;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

// Looks up Cobblemon and Mega Showdown items by registry id at runtime, with
// vanilla fallbacks so the mod still renders sensibly if either dep is
// missing or the id has changed in a future version. Results are cached so
// each lookup happens at most once per server lifetime.
public final class ModItems {

    private static final ConcurrentMap<String, class_1792> CACHE = new ConcurrentHashMap<>();

    private ModItems() {}

    public static class_1792 get(String namespace, String path, class_1792 fallback) {
        String key = namespace + ":" + path;
        class_1792 cached = CACHE.get(key);
        if (cached != null) return cached;
        class_1792 resolved = fallback;
        try {
            class_1792 i = class_7923.field_41178.method_10223(class_2960.method_60655(namespace, path));
            if (i != null && i != class_1802.field_8162) resolved = i;
        } catch (Throwable ignored) {}
        CACHE.put(key, resolved);
        return resolved;
    }

    public static class_1792 cobblemon(String path, class_1792 fallback) {
        return get("cobblemon", path, fallback);
    }

    public static class_1792 megaShowdown(String path, class_1792 fallback) {
        return get("mega_showdown", path, fallback);
    }

    // ---- Convenience accessors -----------------------------------------

    public static class_1792 rareCandy()      { return cobblemon("rare_candy", class_1802.field_8463); }
    public static class_1792 experienceCandyL() { return cobblemon("experience_candy_l", class_1802.field_8071); }

    public static class_1792 shinyStone()     { return cobblemon("shiny_stone", class_1802.field_8137); }
    public static class_1792 linkCable()      { return cobblemon("link_cable", class_1802.field_8719); }

    public static class_1792 abilityCapsule() { return cobblemon("ability_capsule", class_1802.field_8449); }
    public static class_1792 abilityPatch()   { return cobblemon("ability_patch", class_1802.field_8634); }
    public static class_1792 abilityShield()  { return cobblemon("ability_shield", class_1802.field_8255); }

    // EV vitamins — mapped to the six Pokémon stats in their canonical order.
    public static class_1792 vitaminFor(int statIndex) {
        return switch (statIndex) {
            case 0 -> cobblemon("hp_up", class_1802.field_8463);
            case 1 -> cobblemon("protein", class_1802.field_8371);
            case 2 -> cobblemon("iron", class_1802.field_8255);
            case 3 -> cobblemon("calcium", class_1802.field_8894);
            case 4 -> cobblemon("zinc", class_1802.field_8161);
            case 5 -> cobblemon("carbos", class_1802.field_8479);
            default -> class_1802.field_8407;
        };
    }

    // Hyper-training "candies" — same six-stat mapping, used for the IV editor.
    public static class_1792 hyperCandyFor(int statIndex) {
        return switch (statIndex) {
            case 0 -> cobblemon("health_candy", class_1802.field_8463);
            case 1 -> cobblemon("mighty_candy", class_1802.field_8371);
            case 2 -> cobblemon("tough_candy", class_1802.field_8255);
            case 3 -> cobblemon("smart_candy", class_1802.field_8894);
            case 4 -> cobblemon("courage_candy", class_1802.field_8161);
            case 5 -> cobblemon("quick_candy", class_1802.field_8479);
            default -> class_1802.field_8407;
        };
    }

    public static class_1792 natureMint(String natureName) {
        if (natureName == null) return class_1802.field_8674;
        String path = natureName.toLowerCase().trim() + "_mint";
        return cobblemon(path, class_1802.field_8674);
    }

    public static class_1792 teraShard(String typeName) {
        if (typeName == null) return class_1802.field_27063;
        String path = typeName.toLowerCase().trim() + "_tera_shard";
        return megaShowdown(path, class_1802.field_27063);
    }

    public static class_1792 dynamaxCandy() { return megaShowdown("dynamax_candy", class_1802.field_8613); }
    public static class_1792 dynamaxBand()  { return megaShowdown("dynamax_band", class_1802.field_8712); }
    public static class_1792 maxMushroom()  { return megaShowdown("max_mushroom", class_1802.field_17517); }

    public static class_1792 keystone()     { return megaShowdown("keystone", class_1802.field_27063); }

    // ---- Pokemon icon helpers -----------------------------------------

    // Render the actual Pokemon model in an inventory slot via Cobblemon's
    // PokemonItem. Falls back to a poke ball if the call fails for any reason
    // (e.g. shaded/relocated PokemonItem class on a non-standard build).
    public static class_1799 pokemonIcon(Pokemon pokemon) {
        try {
            class_1799 stack = PokemonItem.from(pokemon);
            if (stack != null && !stack.method_7960()) return stack;
        } catch (Throwable ignored) {}
        return new class_1799(caughtBallItem(pokemon, class_1802.field_8543));
    }

    public static class_1792 caughtBallItem(Pokemon pokemon, class_1792 fallback) {
        try {
            PokeBall ball = pokemon.getCaughtBall();
            if (ball == null) return fallback;
            class_1792 i = ball.item();
            if (i != null && i != class_1802.field_8162) return i;
            // Fallback: lookup by registry id from ball.getName()
            return get(ball.getName().method_12836(), ball.getName().method_12832(), fallback);
        } catch (Throwable t) {
            return fallback;
        }
    }

    public static class_1792 pokeBallItemByName(String ballPath, class_1792 fallback) {
        return cobblemon(ballPath, fallback);
    }
}
