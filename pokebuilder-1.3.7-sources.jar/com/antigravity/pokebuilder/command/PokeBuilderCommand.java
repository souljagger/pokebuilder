package com.antigravity.pokebuilder.command;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.PokeBuilderConstants;
import com.antigravity.pokebuilder.gui.PartySelectGui;
import com.antigravity.pokebuilder.gui.admin.AdminGui;
import com.antigravity.pokebuilder.gui.base.GuiManager;
import com.antigravity.pokebuilder.logging.AuditLogReader;
import com.antigravity.pokebuilder.util.PermissionHelper;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;

import java.nio.file.Path;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1934;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9247;

public final class PokeBuilderCommand {

    private PokeBuilderCommand() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        LiteralArgumentBuilder<class_2168> root = method_9247("pokebuilder")
                .executes(PokeBuilderCommand::openParty)
                .then(method_9247("reload")
                        .requires(src -> PermissionHelper.has(src, PokeBuilderConstants.PERM_ADMIN_RELOAD, 3))
                        .executes(PokeBuilderCommand::reload))
                .then(method_9247("save")
                        .requires(src -> PermissionHelper.has(src, PokeBuilderConstants.PERM_ADMIN_SAVE, 4))
                        .executes(PokeBuilderCommand::save))
                .then(method_9247("admin")
                        .requires(src -> PermissionHelper.has(src, PokeBuilderConstants.PERM_ADMIN_GUI, 4))
                        .executes(PokeBuilderCommand::openAdmin))
                .then(method_9247("debug")
                        .requires(src -> PermissionHelper.has(src, PokeBuilderConstants.PERM_ADMIN_DEBUG, 4))
                        .executes(PokeBuilderCommand::debug))
                .then(method_9247("history")
                        .executes(ctx -> history(ctx, 1))
                        .then(com.mojang.brigadier.builder.RequiredArgumentBuilder
                                .<class_2168, Integer>argument("page", IntegerArgumentType.integer(1))
                                .executes(ctx -> history(ctx, IntegerArgumentType.getInteger(ctx, "page"))))
                        .then(method_9247("player")
                                .requires(src -> PermissionHelper.has(src,
                                        PokeBuilderConstants.PERM_ADMIN_HISTORY, 3))
                                .then(com.mojang.brigadier.builder.RequiredArgumentBuilder
                                        .<class_2168, String>argument("name", StringArgumentType.word())
                                        .executes(ctx -> historyForOther(ctx,
                                                StringArgumentType.getString(ctx, "name"), 1))
                                        .then(com.mojang.brigadier.builder.RequiredArgumentBuilder
                                                .<class_2168, Integer>argument("page", IntegerArgumentType.integer(1))
                                                .executes(ctx -> historyForOther(ctx,
                                                        StringArgumentType.getString(ctx, "name"),
                                                        IntegerArgumentType.getInteger(ctx, "page")))))))
                .then(method_9247("version").executes(PokeBuilderCommand::version));

        dispatcher.register(root);
        dispatcher.register(method_9247("pokebuild").executes(PokeBuilderCommand::openParty));
        LiteralArgumentBuilder<class_2168> pb = method_9247("pb")
                .executes(PokeBuilderCommand::openParty)
                // Player-facing shortcut so folks don't have to type
                // /pokebuilder history — /pb history works too.
                .then(method_9247("history")
                        .executes(ctx -> history(ctx, 1))
                        .then(com.mojang.brigadier.builder.RequiredArgumentBuilder
                                .<class_2168, Integer>argument("page", IntegerArgumentType.integer(1))
                                .executes(ctx -> history(ctx, IntegerArgumentType.getInteger(ctx, "page")))));
        dispatcher.register(pb);
    }

    private static int openParty(com.mojang.brigadier.context.CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player;
        try {
            player = src.method_9207();
        } catch (Exception e) {
            src.method_9213(PokeBuilder.get().config().messages.get("command.not_player"));
            return 0;
        }

        if (!PokeBuilder.get().isEnabled()) {
            player.method_7353(PokeBuilder.get().config().messages.get("command.disabled"), false);
            return 0;
        }

        if (!PermissionHelper.has(src, PokeBuilderConstants.PERM_USE, 0)) {
            player.method_7353(PokeBuilder.get().config().messages.get("command.no_permission"), false);
            return 0;
        }

        if (player.field_13974.method_14257() == class_1934.field_9219) {
            player.method_7353(PokeBuilder.get().config().messages.get("command.spectator_blocked"), false);
            return 0;
        }

        if (!PokeBuilder.get().config().security.allowCreativeMode
                && player.field_13974.method_14257() == class_1934.field_9220) {
            player.method_7353(PokeBuilder.get().config().messages.get("command.creative_blocked"), false);
            return 0;
        }

        if (GuiManager.isOpen(player.method_5667())) {
            player.method_7353(PokeBuilder.get().config().messages.get("command.already_open"), false);
            return 0;
        }

        new PartySelectGui(player).open();
        return 1;
    }

    private static int reload(com.mojang.brigadier.context.CommandContext<class_2168> ctx) {
        PokeBuilder.get().reloadConfig();
        ctx.getSource().method_9226(() -> PokeBuilder.get().config().messages.get("command.reloaded"), true);
        // Echo the currently-bound currency so admins editing currency-id
        // can confirm their change was picked up (common support question).
        try {
            var cur = com.antigravity.pokebuilder.economy.EconomyHandler.currency();
            if (cur != null) {
                ctx.getSource().method_9226(() -> net.minecraft.class_2561.method_43470(
                        "Economy currency: " + cur.key()
                ).method_27692(net.minecraft.class_124.field_1080), false);
            }
        } catch (Throwable ignored) {}
        return 1;
    }

    private static int save(com.mojang.brigadier.context.CommandContext<class_2168> ctx) {
        boolean ok = PokeBuilder.get().saveConfig();
        String key = ok ? "command.saved" : "command.save_failed";
        ctx.getSource().method_9226(() -> PokeBuilder.get().config().messages.get(key), true);
        return ok ? 1 : 0;
    }

    private static int openAdmin(com.mojang.brigadier.context.CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        class_3222 player;
        try {
            player = src.method_9207();
        } catch (Exception e) {
            src.method_9213(PokeBuilder.get().config().messages.get("command.not_player"));
            return 0;
        }
        if (!PermissionHelper.has(src, PokeBuilderConstants.PERM_ADMIN_GUI, 4)) {
            player.method_7353(PokeBuilder.get().config().messages.get("command.no_permission"), false);
            return 0;
        }
        if (GuiManager.isOpen(player.method_5667())) {
            player.method_7353(PokeBuilder.get().config().messages.get("command.already_open"), false);
            return 0;
        }
        new AdminGui(player).open();
        return 1;
    }

    private static int version(com.mojang.brigadier.context.CommandContext<class_2168> ctx) {
        ctx.getSource().method_9226(() -> class_2561.method_43470(
                PokeBuilderConstants.MOD_NAME + " v" + PokeBuilderConstants.VERSION
        ).method_27692(class_124.field_1065), false);
        return 1;
    }

    private static int history(CommandContext<class_2168> ctx, int page) {
        class_2168 src = ctx.getSource();
        class_3222 player;
        try {
            player = src.method_9207();
        } catch (Exception e) {
            src.method_9213(PokeBuilder.get().config().messages.get("command.not_player"));
            return 0;
        }
        return renderHistory(src, player.method_5667(), player.method_5477().getString(), page);
    }

    private static int historyForOther(CommandContext<class_2168> ctx, String name, int page) {
        class_2168 src = ctx.getSource();
        class_3222 target = PokeBuilder.get().server().method_3760().method_14566(name);
        if (target == null) {
            src.method_9213(class_2561.method_43470("Player not online: " + name).method_27692(class_124.field_1061));
            return 0;
        }
        return renderHistory(src, target.method_5667(), target.method_5477().getString(), page);
    }

    private static int renderHistory(class_2168 src, UUID playerId, String playerName, int page) {
        int pageSize = 20;
        Path logFile = Path.of(PokeBuilder.get().config().logging.logFile);
        // Over-fetch by one page so we know whether a "next page" exists
        // without a second disk scan.
        List<AuditLogReader.Entry> all = AuditLogReader.tail(logFile, playerId, page * pageSize + 1);
        int startIdx = (page - 1) * pageSize;
        if (startIdx >= all.size()) {
            src.method_9226(() -> PokeBuilder.get().config().messages.get("history.empty"), false);
            return 0;
        }
        int endIdx = Math.min(startIdx + pageSize, all.size());
        boolean hasNext = all.size() > endIdx;
        int totalPages = hasNext ? page + 1 : page; // best-effort — we don't scan the whole log

        final int shownPage = page;
        final int shownTotal = totalPages;
        src.method_9226(() -> PokeBuilder.get().config().messages.get(
                "history.header", shownPage, shownTotal), false);

        for (int i = startIdx; i < endIdx; i++) {
            AuditLogReader.Entry e = all.get(i);
            final String ts = e.timestamp();
            final String txId = e.txId();
            final String action = e.action().toLowerCase();
            final String cost = e.cost();
            final String curr = " " + com.antigravity.pokebuilder.util.TextHelper.currencyName();
            src.method_9226(() -> PokeBuilder.get().config().messages.get(
                    "history.entry", ts, txId, action, cost, curr), false);
        }
        if (hasNext) {
            final int next = page + 1;
            src.method_9226(() -> PokeBuilder.get().config().messages.get(
                    "history.footer", next), false);
        }
        return 1;
    }

    // Dumps the economy state PokeBuilder sees — currency, account, balance,
    // list of registered currencies. Intended for support: an admin runs
    // this and pastes the output so we can diagnose currency routing bugs
    // without needing log access.
    private static int debug(com.mojang.brigadier.context.CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        java.util.UUID requester = null;
        try {
            class_3222 p = src.method_44023();
            if (p != null) requester = p.method_5667();
        } catch (Throwable ignored) {}

        src.method_9226(() -> class_2561.method_43470("=== PokeBuilder debug ===").method_27695(class_124.field_1065, class_124.field_1067), false);
        src.method_9226(() -> class_2561.method_43470("version = " + PokeBuilderConstants.VERSION).method_27692(class_124.field_1080), false);
        src.method_9226(() -> class_2561.method_43470("enabled = " + PokeBuilder.get().isEnabled()).method_27692(class_124.field_1080), false);
        src.method_9226(() -> class_2561.method_43470("dirty   = " + PokeBuilder.get().isDirty()).method_27692(class_124.field_1080), false);

        var cfg = PokeBuilder.get().config();
        src.method_9226(() -> class_2561.method_43470("config.currency-id   = '" + cfg.economy.currencyId + "'").method_27692(class_124.field_1080), false);
        src.method_9226(() -> class_2561.method_43470("config.display-name  = '" + cfg.economy.displayName + "'").method_27692(class_124.field_1080), false);

        for (String line : com.antigravity.pokebuilder.economy.EconomyHandler.dumpDebug(requester)) {
            src.method_9226(() -> class_2561.method_43470(line).method_27692(class_124.field_1080), false);
        }

        // Show whether the requester has any of the bypass nodes —
        // single most-asked support question is "why is my balance not
        // moving" and 9 times out of 10 the answer is "you have
        // pokebuilder.bypass.cost granted via wildcard". Surface it.
        class_3222 player = null;
        try { player = src.method_44023(); } catch (Throwable ignored) {}
        if (player != null) {
            boolean gate = cfg.security.allowBypassPermissions;
            boolean bypassCostPerm = com.antigravity.pokebuilder.util.PermissionHelper
                    .hasExplicit(player, PokeBuilderConstants.PERM_BYPASS_COST);
            boolean bypassCoolPerm = com.antigravity.pokebuilder.util.PermissionHelper
                    .hasExplicit(player, PokeBuilderConstants.PERM_BYPASS_COOLDOWN);
            boolean bypassCostEffective = gate && bypassCostPerm;
            boolean bypassCoolEffective = gate && bypassCoolPerm;

            src.method_9226(() -> class_2561.method_43470("security.allow-bypass-permissions = " + gate
                    + (gate ? "   ← bypass nodes ACTIVE" : "   ← bypass nodes inert (default safe)"))
                    .method_27692(gate ? class_124.field_1054 : class_124.field_1060), false);
            src.method_9226(() -> class_2561.method_43470("bypass.cost     perm=" + bypassCostPerm
                    + " effective=" + bypassCostEffective
                    + (bypassCostEffective ? "   ← every purchase is FREE" : ""))
                    .method_27692(bypassCostEffective ? class_124.field_1061 : class_124.field_1080), false);
            src.method_9226(() -> class_2561.method_43470("bypass.cooldown perm=" + bypassCoolPerm
                    + " effective=" + bypassCoolEffective)
                    .method_27692(bypassCoolEffective ? class_124.field_1054 : class_124.field_1080), false);
            if (bypassCostEffective) {
                src.method_9226(() -> class_2561.method_43470(
                        "  To turn the gate off: edit security.allow-bypass-permissions = false in config"
                ).method_27692(class_124.field_1080), false);
            } else if (gate && bypassCostPerm) {
                // Shouldn't reach here logically, but the comment is for the
                // permission-only-true case.
            } else if (!gate && bypassCostPerm) {
                src.method_9226(() -> class_2561.method_43470(
                        "  (Permission node is granted but ignored — gate is off.)"
                ).method_27692(class_124.field_1080), false);
            }
        }

        src.method_9226(() -> class_2561.method_43470("=========================").method_27695(class_124.field_1065, class_124.field_1067), false);
        return 1;
    }
}
