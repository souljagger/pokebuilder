package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.gui.base.PaginatedGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.api.pokeball.PokeBalls;
import com.cobblemon.mod.common.item.PokeBallItem;
import com.cobblemon.mod.common.pokeball.PokeBall;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class BallSelectGui extends PaginatedGui<PokeBall> {

    private final UUID pokemonId;
    private List<PokeBall> cached;

    public BallSelectGui(class_3222 player, UUID pokemonId) {
        super(player, class_2561.method_43470("PokeBuilder — Ball").method_27692(class_124.field_1062));
        this.pokemonId = pokemonId;
    }

    @Override
    protected List<PokeBall> items() {
        if (cached != null) return cached;
        cached = new ArrayList<>();
        try {
            cached.addAll(PokeBalls.INSTANCE.all());
        } catch (Throwable ignored) {}
        return cached;
    }

    @Override
    protected class_1799 renderItem(PokeBall ball) {
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        boolean current = p != null && p.getCaughtBall().equals(ball);
        BigDecimal cost = PokeBuilder.get().config().prices.ballChange;

        // Each PokeBall has a 1:1 PokeBallItem accessible directly via .item().
        // Earlier versions tried to look up "<name>_pokeball" in the registry,
        // which didn't match the actual item ids and silently fell back to
        // snowballs.
        class_1799 base;
        try {
            PokeBallItem item = ball.item();
            base = item != null ? new class_1799(item) : new class_1799(class_1802.field_8543);
        } catch (Throwable t) {
            base = new class_1799(class_1802.field_8543);
        }

        ItemBuilder b = ItemBuilder.of(base)
                .name(prettyBallName(ball.getName().method_12832()), class_124.field_1075, class_124.field_1067)
                .lore("Cost: " + TextHelper.formatMoney(cost) + " " + TextHelper.currencyName(), class_124.field_1054);
        if (current) b.lore("[CURRENT]", class_124.field_1060, class_124.field_1067).glow(true);
        return b.build();
    }

    private static String prettyBallName(String raw) {
        if (raw == null || raw.isEmpty()) return "Ball";
        StringBuilder out = new StringBuilder();
        boolean upper = true;
        for (char c : raw.toCharArray()) {
            if (c == '_') { out.append(' '); upper = true; continue; }
            out.append(upper ? Character.toUpperCase(c) : c);
            upper = false;
        }
        return out.toString();
    }

    @Override
    protected void onItemClick(PokeBall ball) {
        if (!FeatureGate.enforce(FeatureGate.Feature.BALL, player)) { close(); return; }
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }
        if (p.getCaughtBall().equals(ball)) return;

        BigDecimal cost = PokeBuilder.get().config().prices.ballChange;
        String name = ball.getName().method_12832();
        TransactionService.execute(player, pokemonId, FeatureGate.Feature.BALL,
                "BALL_SET", name, cost, pm -> PokemonModifier.setBall(pm, name));
        refresh();
    }

    @Override
    protected void onBack() {
        SoundHelper.back(player);
        new EditorGui(player, pokemonId).open();
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
