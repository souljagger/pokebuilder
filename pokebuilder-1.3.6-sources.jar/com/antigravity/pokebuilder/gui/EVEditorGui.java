package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.config.PokeBuilderConfig;
import com.antigravity.pokebuilder.gui.base.BaseGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.api.pokemon.stats.Stats;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class EVEditorGui extends BaseGui {

    private static final int[] HEADER_SLOTS = {10, 11, 12, 13, 14, 15};
    private static final int[] SET252_SLOTS = {19, 20, 21, 22, 23, 24};
    private static final int[] SET0_SLOTS = {28, 29, 30, 31, 32, 33};
    private static final int TOTAL_SLOT = 40;
    private static final int BACK_SLOT = 45;
    private static final int RESET_ALL_SLOT = 52;
    private static final int CLOSE_SLOT = 53;

    private final UUID pokemonId;

    public EVEditorGui(class_3222 player, UUID pokemonId) {
        super(player, 6, class_2561.method_43470("\u2756 PokeBuilder \u00b7 EVs \u2756").method_27695(class_124.field_1062, class_124.field_1067));
        this.pokemonId = pokemonId;
    }

    @Override
    protected void build() {
        fillBorders(PokeBuilder.get().config().looks.borderColor);
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }
        PokeBuilderConfig cfg = PokeBuilder.get().config();

        Stats[] stats = CobblemonBridge.allStats();
        int total = 0;
        for (int i = 0; i < 6; i++) {
            int current = p.getEvs().get(stats[i]);
            total += current;
        }
        for (int i = 0; i < 6; i++) {
            int current = p.getEvs().get(stats[i]);
            class_1792 icon = ModItems.vitaminFor(i);
            boolean canAdd = current < 252 && total < 510;
            ItemBuilder hdr = ItemBuilder.of(icon)
                    .name(CobblemonBridge.statLabel(stats[i]) + ": " + current + " / 252",
                            colorForEv(current), class_124.field_1067)
                    .lore("Effort value", class_124.field_1063);
            if (canAdd) {
                hdr.lore("Click: +10 EVs", class_124.field_1075);
                hdr.lore("Cost: " + TextHelper.formatMoney(cfg.prices.ev.add10) + " " + TextHelper.currencyName(), class_124.field_1054);
            } else {
                hdr.lore("Maxed out", class_124.field_1060);
            }
            safeSet(HEADER_SLOTS[i], hdr.glow(current == 252).build());

            boolean capped = current >= 252;
            safeSet(SET252_SLOTS[i], ItemBuilder.of(capped ? class_1802.field_8581 : class_1802.field_8131)
                    .name("Set to 252", capped ? class_124.field_1063 : class_124.field_1060, class_124.field_1067)
                    .lore(capped ? "Already at 252" : "Cost: " + TextHelper.formatMoney(cfg.prices.ev.setSingle252) + " " + TextHelper.currencyName(),
                            capped ? class_124.field_1060 : class_124.field_1054)
                    .glow(capped).build());

            boolean zeroed = current <= 0;
            safeSet(SET0_SLOTS[i], ItemBuilder.of(zeroed ? class_1802.field_8879 : class_1802.field_8264)
                    .name("Set to 0", zeroed ? class_124.field_1063 : class_124.field_1061, class_124.field_1067)
                    .lore(zeroed ? "Already zero" : "Cost: " + TextHelper.formatMoney(cfg.prices.ev.setSingle0) + " " + TextHelper.currencyName(),
                            zeroed ? class_124.field_1060 : class_124.field_1054)
                    .build());
        }

        safeSet(TOTAL_SLOT, ItemBuilder.of(class_1802.field_8529)
                .name("Total EVs: " + total + " / 510", class_124.field_1065, class_124.field_1067).build());

        safeSet(BACK_SLOT, ItemBuilder.of(class_1802.field_8107).name("Back", class_124.field_1054).build());
        if (PokeBuilder.get().config().features.evResetAll) {
            safeSet(RESET_ALL_SLOT, ItemBuilder.of(class_1802.field_8733)
                    .name("Reset All EVs", class_124.field_1060, class_124.field_1067)
                    .lore("Cost: " + TextHelper.formatMoney(cfg.prices.ev.resetAll) + " " + TextHelper.currencyName(), class_124.field_1054)
                    .build());
        }
        safeSet(CLOSE_SLOT, ItemBuilder.of(class_1802.field_8077).name("Close", class_124.field_1061).build());
    }

    @Override
    public void onSlotClick(int slot, int button, class_1713 action) {
        if (slot == BACK_SLOT) { SoundHelper.back(player); new EditorGui(player, pokemonId).open(); return; }
        if (slot == CLOSE_SLOT) { close(); return; }
        if (!FeatureGate.enforce(FeatureGate.Feature.EV_EDITOR, player)) { close(); return; }
        if (slot == RESET_ALL_SLOT) {
            if (!FeatureGate.enforce(FeatureGate.Feature.EV_RESET_ALL, player)) return;
            BigDecimal cost = PokeBuilder.get().config().prices.ev.resetAll;
            TransactionService.execute(player, pokemonId, FeatureGate.Feature.EV_RESET_ALL,
                    "EV_RESET_ALL", "all0", cost, PokemonModifier::resetAllEvs);
            refresh();
            return;
        }

        Stats[] stats = CobblemonBridge.allStats();
        for (int i = 0; i < 6; i++) {
            if (HEADER_SLOTS[i] == slot) {
                Pokemon pokemon = CobblemonBridge.findByUuid(player, pokemonId);
                if (pokemon == null) { close(); return; }
                int current = pokemon.getEvs().get(stats[i]);
                int evTotal = PokemonModifier.totalEvs(pokemon);
                if (current >= 252 || evTotal >= 510) {
                    player.method_7353(net.minecraft.class_2561.method_43470("EVs already at maximum.")
                            .method_27692(class_124.field_1061), false);
                    SoundHelper.purchaseFailed(player);
                    return;
                }
                final Stats s = stats[i];
                BigDecimal cost = PokeBuilder.get().config().prices.ev.add10;
                TransactionService.execute(player, pokemonId, FeatureGate.Feature.EV_EDITOR,
                        "EV_ADD_10", CobblemonBridge.statLabel(s), cost,
                        pm -> PokemonModifier.addEv(pm, s, 10));
                refresh();
                return;
            }
            if (SET252_SLOTS[i] == slot) {
                final Stats s = stats[i];
                BigDecimal cost = PokeBuilder.get().config().prices.ev.setSingle252;
                TransactionService.execute(player, pokemonId, FeatureGate.Feature.EV_EDITOR,
                        "EV_SET_252", CobblemonBridge.statLabel(s), cost, p -> PokemonModifier.setEv(p, s, 252));
                refresh();
                return;
            }
            if (SET0_SLOTS[i] == slot) {
                final Stats s = stats[i];
                BigDecimal cost = PokeBuilder.get().config().prices.ev.setSingle0;
                TransactionService.execute(player, pokemonId, FeatureGate.Feature.EV_EDITOR,
                        "EV_SET_0", CobblemonBridge.statLabel(s), cost, p -> PokemonModifier.setEv(p, s, 0));
                refresh();
                return;
            }
        }
    }

    private static class_124 colorForEv(int value) {
        if (value >= 252) return class_124.field_1060;
        if (value >= 190) return class_124.field_1075;
        if (value >= 128) return class_124.field_1054;
        if (value > 0) return class_124.field_1065;
        return class_124.field_1061;
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
