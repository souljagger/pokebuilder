package com.antigravity.pokebuilder.gui;

import com.antigravity.pokebuilder.PokeBuilder;
import com.antigravity.pokebuilder.gui.base.PaginatedGui;
import com.antigravity.pokebuilder.service.CobblemonBridge;
import com.antigravity.pokebuilder.service.FeatureGate;
import com.antigravity.pokebuilder.service.PokemonModifier;
import com.antigravity.pokebuilder.service.TransactionService;
import com.antigravity.pokebuilder.util.ItemBuilder;
import com.antigravity.pokebuilder.util.ModItems;
import com.antigravity.pokebuilder.util.SoundHelper;
import com.antigravity.pokebuilder.util.TextHelper;
import com.cobblemon.mod.common.api.types.tera.TeraType;
import com.cobblemon.mod.common.api.types.tera.TeraTypes;
import com.cobblemon.mod.common.pokemon.Pokemon;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class TeraTypeSelectGui extends PaginatedGui<TeraType> {

    private final UUID pokemonId;
    private List<TeraType> cached;

    public TeraTypeSelectGui(class_3222 player, UUID pokemonId) {
        super(player, class_2561.method_43470("PokeBuilder — Tera Type").method_27692(class_124.field_1076));
        this.pokemonId = pokemonId;
    }

    @Override
    protected List<TeraType> items() {
        if (cached != null) return cached;
        cached = new ArrayList<>();
        try {
            for (TeraType t : TeraTypes.INSTANCE) cached.add(t);
        } catch (Throwable ignored) {}
        return cached;
    }

    @Override
    protected class_1799 renderItem(TeraType type) {
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        boolean current = false;
        try {
            current = p != null && p.getTeraType() != null
                    && p.getTeraType().getId().equals(type.getId());
        } catch (Throwable ignored) {}
        BigDecimal cost = PokeBuilder.get().config().prices.teraType;
        String name = type.getName();

        ItemBuilder b = ItemBuilder.of(ModItems.teraShard(name))
                .name(prettyName(name), colorForType(name), class_124.field_1067)
                .lore("Tera Shard: " + prettyName(name), class_124.field_1080);

        if (current) {
            b.lore("[CURRENT]", class_124.field_1060, class_124.field_1067).glow(true);
        } else {
            b.lore("Cost: " + TextHelper.formatMoney(cost) + " " + TextHelper.currencyName(), class_124.field_1054);
            b.lore("Click to re-type", class_124.field_1080);
        }
        return b.build();
    }

    private static String prettyName(String raw) {
        if (raw == null || raw.isEmpty()) return "—";
        String lower = raw.toLowerCase();
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }

    private static class_124 colorForType(String name) {
        return switch (name == null ? "" : name.toLowerCase()) {
            case "fire" -> class_124.field_1061;
            case "water" -> class_124.field_1078;
            case "grass" -> class_124.field_1060;
            case "electric" -> class_124.field_1054;
            case "ice" -> class_124.field_1075;
            case "fighting" -> class_124.field_1079;
            case "poison" -> class_124.field_1064;
            case "ground" -> class_124.field_1065;
            case "flying" -> class_124.field_1068;
            case "psychic" -> class_124.field_1076;
            case "bug" -> class_124.field_1077;
            case "rock" -> class_124.field_1063;
            case "ghost" -> class_124.field_1064;
            case "dragon" -> class_124.field_1058;
            case "dark" -> class_124.field_1074;
            case "steel" -> class_124.field_1080;
            case "fairy" -> class_124.field_1076;
            case "stellar" -> class_124.field_1065;
            default -> class_124.field_1068;
        };
    }

    @Override
    protected void onItemClick(TeraType type) {
        if (!FeatureGate.enforce(FeatureGate.Feature.TERA_TYPE, player)) { close(); return; }
        Pokemon p = CobblemonBridge.findByUuid(player, pokemonId);
        if (p == null) { close(); return; }
        try {
            if (p.getTeraType() != null && p.getTeraType().getId().equals(type.getId())) return;
        } catch (Throwable ignored) {}
        BigDecimal cost = PokeBuilder.get().config().prices.teraType;
        TransactionService.execute(player, pokemonId, FeatureGate.Feature.TERA_TYPE,
                "TERA_TYPE", type.getName(), cost,
                pm -> PokemonModifier.setTeraType(pm, type));
        refresh();
    }

    @Override
    protected void onBack() {
        SoundHelper.back(player);
        new EditorGui(player, pokemonId).open();
    }

    @Override
    protected void onOpen() { SoundHelper.openMenu(player); }
}
